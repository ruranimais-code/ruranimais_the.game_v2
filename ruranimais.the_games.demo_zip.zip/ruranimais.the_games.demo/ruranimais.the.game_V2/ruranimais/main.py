"""
ruranimais - The Game
Corrida infinita em PyGame: escolha um gato ou um cachorro, fuja da parede de fogo,
desvie dos obstáculos e pegue as comidas. Elas viram moedas para comprar skins na loja.

Como rodar:
    pip install pygame
    python main.py

Organização do código:
    config.py        números e teclas ajustáveis
    skins.py         catálogo de skins da loja (nomes e preços)
    logica.py        regras do jogo (sem desenhar nada)
    mundo.py         desenho do mundo de jogo (cenário, jogador, fogo, efeitos)
    cenario.py       cenário infinito (ciclo inicial -> 2 -> 3 -> 4/5 -> 3 -> ...)
    telas.py         menu, escolha do bichinho, loja, HUD, conquistas, configurações, pausa e fim
    estatisticas.py  recorde, totais e conquistas (salvos em save.json)
    assets.py        carregamento de imagens e sons
    main.py          estados do jogo, teclado/mouse e laço principal (este arquivo)
"""
import math
import sys

import pygame

import config as C
from assets import Imagens, Sons
from cenario import Cenario
from estatisticas import Progresso
from logica import Partida
from mundo import Mundo
from telas import Telas
import skins as SK

PASSO_MAX = 1 / 90           # a lógica roda em passos de no máximo 1/90 s
TEMPO_MORTE = 1.5            # duração da onda de fogo no fim de jogo
BLOQUEIO_FIM = 0.8           # tempo em que a tela de fim ignora teclas (evita apertar sem querer)

CONFIRMAR = (pygame.K_RETURN, pygame.K_KP_ENTER)
CIMA = (pygame.K_UP, pygame.K_w)
BAIXO = (pygame.K_DOWN, pygame.K_s)
ESQUERDA = (pygame.K_LEFT, pygame.K_a)
DIREITA = (pygame.K_RIGHT, pygame.K_d)


def _tecla_em(tecla, nome):
    return tecla in C.TECLAS[nome]


class Jogo:
    """Guarda o estado atual (menu, jogando, pausa...) e liga teclado, lógica e desenho."""

    def __init__(self, tela):
        self.tela = tela
        self.img = Imagens()
        self.sons = Sons()
        self.prog = Progresso()
        self.telas = Telas(self.img)
        self.estado = "menu"      # menu | escolha | loja | jogando | morrendo | fim | pausa | conquistas | config
        self.sel = 0              # opção selecionada na tela atual
        self.t = 0.0              # relógio de animação das telas
        self.tela_cheia = False
        self.confirmar_apagar = False
        self.sair = False
        self.partida = self.mundo = None
        self.resultado = None
        self.t_estado = 0.0
        self.t_conquistas = 0.0
        self.novas_na_corrida = []
        self.animal = self.prog.dados["animal"]      # bichinho com que se joga
        self.loja_aba = 0                            # 0 = cachorro, 1 = gato (aba aberta na loja)
        self.loja_volta = "menu"                     # para onde o Esc da loja leva
        self.msg_loja = None                         # (texto, cor) ; some depois de 2 s
        self.t_msg = 0.0

    # ----------------------------------------------------------------- áudio
    def som(self, nome):
        self.sons.tocar(nome, self.prog.dados["efeitos"])

    # ------------------------------------------------------- troca de estado
    def ir_para(self, estado, sel=0):
        self.estado, self.sel, self.t_estado = estado, sel, 0.0
        self.confirmar_apagar = False

    def nova_partida(self):
        self.partida = Partida()
        self.mundo = Mundo(self.img, Cenario(self.img.cen_corpo, self.img.cen_trans),
                           self.animal, self.prog.skin_atual(self.animal))
        self.novas_na_corrida = []
        self.t_conquistas = 0.0
        self.resultado = None
        self.telas.toasts.clear()
        self.sons.pausar(False)
        self.sons.musica_ligar(self.prog.dados["musica"])
        self.ir_para("jogando")

    def voltar_ao_menu(self, sel=0):
        self.sons.pausar(False)
        self.sons.musica_ligar(False)
        self.partida = self.mundo = None
        self.ir_para("menu", sel)

    def pausar(self):
        if self.estado == "jogando":
            self.sons.pausar(True)
            self.ir_para("pausa")

    def continuar(self):
        self.sons.pausar(False)
        self.estado = "jogando"
        # se o jogador soltou a tecla de pulo durante a pausa, o pulo não fica "preso"
        teclas = pygame.key.get_pressed()
        if not any(teclas[k] for k in C.TECLAS["pular"]):
            self.partida.soltar_pulo()

    # --------------------------------------------------------------- eventos
    def evento(self, ev):
        if ev.type == pygame.QUIT:
            self.sair = True
            return
        # perdeu o foco da janela durante a corrida: pausa sozinho
        if ev.type == getattr(pygame, "WINDOWFOCUSLOST", -1):
            self.pausar()
            return
        if ev.type == pygame.KEYDOWN and ev.key == pygame.K_F11:
            self.alternar_tela_cheia()
            return

        if self.estado == "jogando":
            self._evento_jogo(ev)
        elif self.estado in ("menu", "pausa", "fim", "config", "escolha"):
            self._evento_lista(ev)
        elif self.estado == "loja":
            self._evento_loja(ev)
        elif self.estado == "conquistas":
            if (ev.type == pygame.KEYDOWN and ev.key in (pygame.K_ESCAPE, pygame.K_BACKSPACE, *CONFIRMAR)) \
                    or (ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1):
                self.som("menu_ok")
                self.ir_para("menu", 2)                # o cursor volta em "Conquistas"

    # ---- durante a corrida
    def _evento_jogo(self, ev):
        p = self.partida
        if ev.type == pygame.KEYDOWN:
            if _tecla_em(ev.key, "pausa"):
                self.pausar()
            elif _tecla_em(ev.key, "pular"):
                p.pedir_pulo()
        elif ev.type == pygame.KEYUP and _tecla_em(ev.key, "pular"):
            teclas = pygame.key.get_pressed()
            if not any(teclas[k] for k in C.TECLAS["pular"]):
                p.soltar_pulo()

    # ---- telas com lista de opções (menu, pausa, fim, configurações)
    def _rets(self):
        t = self.telas
        return {"menu": t.rets_menu, "pausa": t.rets_pausa, "fim": t.rets_fim,
                "config": t.rets_config, "escolha": t.rets_escolha}[self.estado]

    def _evento_lista(self, ev):
        n = len(self._rets())
        horizontal = self.estado in ("fim", "escolha")
        if self.estado == "fim" and self.t_estado < BLOQUEIO_FIM:
            return                                           # ainda bloqueado
        if ev.type == pygame.KEYDOWN:
            k = ev.key
            anterior = ESQUERDA if horizontal else CIMA
            proximo = DIREITA if horizontal else BAIXO
            if k in anterior or (horizontal and k in CIMA):
                self._mover_sel(-1, n)
            elif k in proximo or (horizontal and k in BAIXO):
                self._mover_sel(+1, n)
            elif k in CONFIRMAR or (k == pygame.K_SPACE and self.estado != "fim"):
                self._ativar(self.sel)
            elif self.estado == "config" and k in (pygame.K_LEFT, pygame.K_RIGHT) and self.sel < 3:
                self._ativar(self.sel)
            elif k == pygame.K_ESCAPE:
                self._voltar()
            elif self.estado == "pausa" and _tecla_em(k, "pausa"):
                self._voltar()
            elif self.estado == "fim" and k == pygame.K_r:
                self.som("menu_ok")
                self.nova_partida()
            elif self.estado in ("fim", "escolha") and k == pygame.K_l:
                self.som("menu_ok")
                self.abrir_loja(self.estado)
            elif self.estado == "fim" and k == pygame.K_m:
                self.som("menu_ok")
                self.voltar_ao_menu()
        elif ev.type == pygame.MOUSEMOTION:
            for i, r in enumerate(self._rets()):
                if r.collidepoint(ev.pos) and i != self.sel:
                    self.sel = i
                    self.confirmar_apagar = False
                    self.som("menu_move")
        elif ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
            for i, r in enumerate(self._rets()):
                if r.collidepoint(ev.pos):
                    self.sel = i
                    self._ativar(i)
                    break

    def _mover_sel(self, delta, n):
        self.sel = (self.sel + delta) % n
        self.confirmar_apagar = False
        self.som("menu_move")

    def _voltar(self):
        """Esc: o que 'voltar' significa em cada tela."""
        if self.estado == "pausa":
            self.continuar()
        elif self.estado == "config":
            self.som("menu_ok")
            self.ir_para("menu", 3)
        elif self.estado == "escolha":
            self.som("menu_ok")
            self.ir_para("menu", 0)
        elif self.estado == "fim":
            self.som("menu_ok")
            self.voltar_ao_menu()
        # no menu principal, Esc não faz nada (para não fechar sem querer)

    def _ativar(self, i):
        e = self.estado
        if e == "menu":
            self.som("menu_ok")
            if i == 0:
                self.ir_para("escolha", SK.ANIMAIS.index(self.animal))
            elif i == 1:
                self.abrir_loja("menu")
            elif i == 2:
                self.ir_para("conquistas")
            else:
                self.ir_para("config")
        elif e == "escolha":
            self.som("menu_ok")
            self.animal = SK.ANIMAIS[i]
            self.prog.escolher_animal(self.animal)
            self.prog.salvar()
            self.nova_partida()
        elif e == "pausa":
            self.som("menu_ok")
            if i == 0:
                self.continuar()
            elif i == 1:
                self.nova_partida()
            else:
                self.voltar_ao_menu()
        elif e == "fim":
            self.som("menu_ok")
            if i == 0:
                self.nova_partida()
            else:
                self.voltar_ao_menu()
        elif e == "config":
            self._ativar_config(i)

    def _ativar_config(self, i):
        d = self.prog.dados
        self.som("menu_ok")
        if i == 0:
            d["musica"] = not d["musica"]
            self.prog.salvar()
        elif i == 1:
            d["efeitos"] = not d["efeitos"]
            self.prog.salvar()
            self.som("menu_ok")
        elif i == 2:
            self.alternar_tela_cheia()
        elif i == 3:
            if self.confirmar_apagar:
                self.prog.apagar()
                self.confirmar_apagar = False
            else:
                self.confirmar_apagar = True
        else:
            self.ir_para("menu", 3)

    # ------------------------------------------------------------------ loja
    def abrir_loja(self, de):
        """Abre a loja já na aba do bichinho atual. `de` = tela para onde o Esc volta."""
        self.loja_volta = de
        self.loja_aba = SK.ANIMAIS.index(self.animal)
        self.msg_loja = None
        self.ir_para("loja", SK.lista(SK.ANIMAIS[self.loja_aba]).index(
            SK.info(SK.ANIMAIS[self.loja_aba], self.prog.skin_atual(SK.ANIMAIS[self.loja_aba]))))

    def _evento_loja(self, ev):
        n = len(SK.lista(SK.ANIMAIS[self.loja_aba]))
        t = self.telas
        if ev.type == pygame.KEYDOWN:
            k = ev.key
            if k in ESQUERDA:
                self.sel = (self.sel - 1) % n; self.som("menu_move")
            elif k in DIREITA:
                self.sel = (self.sel + 1) % n; self.som("menu_move")
            elif k in CIMA or k in BAIXO or k == pygame.K_TAB:
                self._trocar_aba((self.loja_aba + 1) % len(SK.ANIMAIS))
            elif k in CONFIRMAR or k == pygame.K_SPACE:
                self._comprar_ou_equipar()
            elif k in (pygame.K_ESCAPE, pygame.K_BACKSPACE):
                self.som("menu_ok")
                self._sair_da_loja()
        elif ev.type == pygame.MOUSEMOTION:
            for i, r in enumerate(t.rets_loja[:n]):
                if r.collidepoint(ev.pos) and i != self.sel:
                    self.sel = i
                    self.som("menu_move")
        elif ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
            for i, r in enumerate(t.rets_abas):
                if r.collidepoint(ev.pos):
                    self._trocar_aba(i)
                    return
            for i, r in enumerate(t.rets_loja[:n]):
                if r.collidepoint(ev.pos):
                    self.sel = i
                    self._comprar_ou_equipar()
                    return

    def _trocar_aba(self, aba):
        if aba != self.loja_aba:
            self.loja_aba = aba
            animal = SK.ANIMAIS[aba]
            self.sel = SK.lista(animal).index(SK.info(animal, self.prog.skin_atual(animal)))
            self.msg_loja = None
            self.som("menu_move")

    def _comprar_ou_equipar(self):
        animal = SK.ANIMAIS[self.loja_aba]
        skin, nome, preco = SK.lista(animal)[self.sel]
        if self.prog.possui(animal, skin):
            self.prog.equipar(animal, skin)
            self._mensagem(f"{nome} equipada!", C.COR_VERDE_ESC)
            self.som("menu_ok")
            return
        res = self.prog.comprar(animal, skin)
        if res == "ok":
            self._mensagem(f"{nome} comprada e equipada!", C.COR_VERDE_ESC)
            self.som("compra")
            for _id, titulo, _d in self.prog.checar_conquistas():
                self.telas.novo_toast(titulo)
                self.som("conquista")
        elif res == "sem_moedas":
            self._mensagem(f"Faltam {preco - self.prog.moedas} comidas para comprar {nome}", C.COR_VERMELHO)
            self.som("negado")

    def _mensagem(self, texto, cor):
        self.msg_loja, self.t_msg = (texto, cor), 2.2

    def _sair_da_loja(self):
        if self.loja_volta == "fim":
            self.ir_para("fim", 0)
            self.t_estado = BLOQUEIO_FIM          # já passou o bloqueio
        elif self.loja_volta == "escolha":
            self.ir_para("escolha", SK.ANIMAIS.index(self.animal))
        else:
            self.ir_para("menu", 1)

    def alternar_tela_cheia(self):
        self.tela_cheia = not self.tela_cheia
        try:
            pygame.display.toggle_fullscreen()
        except pygame.error:
            self.tela_cheia = not self.tela_cheia

    # ------------------------------------------------------------- atualização
    def atualizar(self, dt):
        self.t += dt
        self.t_estado += dt
        self.telas.atualizar_toasts(dt)
        if self.msg_loja:
            self.t_msg -= dt
            if self.t_msg <= 0:
                self.msg_loja = None

        if self.estado == "jogando":
            self._atualizar_corrida(dt)
        elif self.estado == "morrendo":
            self.mundo.atualizar(dt, self.partida)
            if self.t_estado >= TEMPO_MORTE:
                self.ir_para("fim", 0)

    def _atualizar_corrida(self, dt):
        p = self.partida
        teclas = pygame.key.get_pressed()
        p.deslizar(any(teclas[k] for k in C.TECLAS["deslizar"]))

        passos = max(1, math.ceil(dt / PASSO_MAX))
        for _ in range(passos):
            p.atualizar(dt / passos)
        self.mundo.atualizar(dt, p)
        self._processar_eventos()

        # confere conquistas algumas vezes por segundo
        self.t_conquistas += dt
        if self.t_conquistas >= 0.4 and not p.fim:
            self.t_conquistas = 0.0
            for _id, titulo, _desc in self.prog.checar_conquistas(p, self.animal):
                self.novas_na_corrida.append(titulo)
                self.telas.novo_toast(titulo)
                self.som("conquista")

    def _processar_eventos(self):
        p = self.partida
        eventos, p.eventos = p.eventos, []
        for nome, dados in eventos:
            if nome in ("pulo", "pouso", "deslizar", "batida", "comida"):
                self.som(nome)
            self.mundo.reagir(nome, dados, p)
            if nome == "fim":
                self._fim_de_jogo()

    def _fim_de_jogo(self):
        p = self.partida
        self.sons.musica_ligar(False)
        self.som("fim")
        # pega as conquistas que dependem de números finais e soma a partida aos totais
        novo_recorde, novas = self.prog.registrar_partida(p, self.animal)
        titulos = list(self.novas_na_corrida) + [t for _i, t, _d in novas]
        if novas:
            self.som("conquista")
        self.resultado = dict(metros=p.metros_inteiros, recorde=self.prog.recorde,
                              novo_recorde=novo_recorde and p.metros_inteiros > 0,
                              comidas=p.comidas_pegas, saldo=self.prog.moedas, novas=titulos)
        self.ir_para("morrendo")

    # ---------------------------------------------------------------- desenho
    def desenhar(self):
        tela, e = self.tela, self.estado
        if e == "menu":
            self.telas.desenhar_menu(tela, self.sel, self.t, self.prog.recorde)
        elif e == "conquistas":
            self.telas.desenhar_conquistas(tela, self.prog, self.t)
        elif e == "config":
            self.telas.desenhar_config(tela, self.sel, self.prog, self.tela_cheia,
                                       self.confirmar_apagar, self.t)
        elif e == "escolha":
            self.telas.desenhar_escolha(tela, self.sel, self.prog, self.t)
        elif e == "loja":
            self.telas.desenhar_loja(tela, self.loja_aba, self.sel, self.prog, self.msg_loja, self.t)
            self.telas.desenhar_toasts(tela, topo=True)
        else:
            self._desenhar_partida()
        pygame.display.flip()

    def _desenhar_partida(self):
        tela, e, p = self.tela, self.estado, self.partida
        extra = 0.0
        if e in ("morrendo", "fim"):
            f = min(1.0, self.t_estado / TEMPO_MORTE) if e == "morrendo" else 1.0
            extra = (p.dist_fogo + 270.0) * f * f * (3 - 2 * f)       # onda de fogo engole o jogador e cobre a metade esquerda
        self.mundo.desenhar(tela, p, fogo_extra=extra, piscar=e == "jogando")
        if e in ("jogando", "pausa"):
            self.telas.desenhar_hud(tela, p, self.prog, self.t)
            self.telas.desenhar_toasts(tela)
        if e == "pausa":
            self.telas.desenhar_pausa(tela, self.sel, self.t)
        elif e == "fim":
            self.resultado["saldo"] = self.prog.moedas           # (pode mudar se comprar algo na loja)
            self.telas.desenhar_fim(tela, self.sel, self.resultado, self.t)


def main():
    pygame.mixer.pre_init(22050, -16, 1, 512)
    pygame.init()
    pygame.display.set_caption(C.TITULO)
    tela = pygame.display.set_mode((C.LARGURA, C.ALTURA), pygame.SCALED)
    jogo = Jogo(tela)
    relogio = pygame.time.Clock()

    while not jogo.sair:
        dt = min(relogio.tick(C.FPS) / 1000.0, 0.05)
        for ev in pygame.event.get():
            jogo.evento(ev)
        jogo.atualizar(dt)
        jogo.desenhar()

    jogo.prog.salvar()
    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
