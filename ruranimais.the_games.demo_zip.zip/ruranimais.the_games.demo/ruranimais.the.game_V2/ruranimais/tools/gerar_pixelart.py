"""
Gera os pixel arts que não vieram prontos: obstáculos, gaiola, animais, fogo
e brilho do fogo. Tudo é desenhado em baixa resolução e ampliado (vizinho mais
próximo) para manter o visual pixelado.

Uso:  python tools/gerar_pixelart.py
"""
import math
import os
import random
from PIL import Image, ImageDraw

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SAIDA = os.path.join(RAIZ, "assets", "objetos")
ESC = 3  # ampliação dos obstáculos/animais (1 pixel de arte = 3 pixels na tela)


def hexa(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4)) + (255,)


CONTORNO = hexa("2a1a12")


def novo(w, h):
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    return im, ImageDraw.Draw(im)


def salvar(im, nome, esc=ESC):
    im = im.resize((im.width * esc, im.height * esc), Image.NEAREST)
    im.save(os.path.join(SAIDA, nome))
    return im


# ---------------------------------------------------------------- caixote
def caixote():
    w = h = 22
    im, d = novo(w, h)
    mad, mad_esc, mad_cl = hexa("a8692f"), hexa("7a4a20"), hexa("dca25c")
    d.rectangle([0, 0, w - 1, h - 1], fill=CONTORNO)
    d.rectangle([1, 1, w - 2, h - 2], fill=mad)
    d.rectangle([1, 1, w - 2, 3], fill=mad_cl)          # topo plano e mais claro
    for y in (8, 14):                                    # tábuas
        d.line([1, y, w - 2, y], fill=mad_esc)
    d.rectangle([1, 1, 3, h - 2], fill=mad_esc)          # montantes laterais
    d.rectangle([w - 4, 1, w - 2, h - 2], fill=mad_esc)
    d.line([3, 4, w - 4, h - 3], fill=mad_esc)           # travessa em X
    d.line([w - 4, 4, 3, h - 3], fill=mad_esc)
    d.line([2, 1, w - 3, 1], fill=hexa("f0c487"))
    for x, y in ((2, 2), (w - 3, 2), (2, h - 3), (w - 3, h - 3)):  # pregos
        d.point((x, y), fill=hexa("d9dde3"))
    return salvar(im, "caixote.png")


# ---------------------------------------------------------------- espinhos
def espinhos():
    w, h = 20, 12
    im, d = novo(w, h)
    d.rectangle([0, h - 3, w - 1, h - 1], fill=CONTORNO)
    d.rectangle([1, h - 3, w - 2, h - 2], fill=hexa("4b5563"))
    for i in range(4):
        x0 = 1 + i * 5
        pts = [(x0, h - 4), (x0 + 2, 0), (x0 + 4, h - 4)]
        d.polygon(pts, fill=CONTORNO)
        d.polygon([(x0 + 1, h - 4), (x0 + 2, 2), (x0 + 3, h - 4)], fill=hexa("c9d1d9"))
        d.line([(x0 + 2, 2), (x0 + 3, h - 4)], fill=hexa("8793a0"))
    return salvar(im, "espinhos.png")


# ---------------------------------------------------------------- barreira
def barreira():
    w, h = 34, 24
    im, d = novo(w, h)
    verm, branco = hexa("d62828"), hexa("f4f1ea")
    # pernas
    for x in (3, w - 6):
        d.rectangle([x, 6, x + 2, h - 1], fill=CONTORNO)
        d.rectangle([x + 1, 6, x + 1, h - 1], fill=hexa("b8bec7"))
    # tábua listrada
    d.rectangle([0, 1, w - 1, 7], fill=CONTORNO)
    for x in range(1, w - 1):
        for y in range(2, 7):
            listra = ((x + y) // 3) % 2
            d.point((x, y), fill=verm if listra == 0 else branco)
    # luzes amarelas nas pontas
    for x in (1, w - 4):
        d.rectangle([x, 0, x + 2, 1], fill=hexa("ffd23f"))
    return salvar(im, "barreira.png")


# ---------------------------------------------------------------- animais
def _capivara(d):
    pel, esc = hexa("a06c3b"), hexa("73482a")
    d.rectangle([1, 4, 11, 10], fill=pel)               # corpo
    d.rectangle([10, 3, 14, 8], fill=pel)               # cabeça
    d.rectangle([13, 5, 15, 8], fill=hexa("8a5a30"))    # focinho
    d.rectangle([10, 2, 11, 3], fill=esc)               # orelha
    d.point((12, 4), fill=hexa("1b1b1b"))               # olho
    d.rectangle([2, 10, 3, 12], fill=esc)
    d.rectangle([9, 10, 10, 12], fill=esc)
    d.rectangle([1, 9, 11, 10], fill=esc)


def _arara(d):
    az, az_cl = hexa("1f4fb3"), hexa("3d7bf0")
    d.rectangle([5, 2, 9, 9], fill=az)
    d.rectangle([6, 1, 9, 4], fill=az_cl)
    d.rectangle([8, 3, 10, 5], fill=hexa("f3d03e"))     # face amarela
    d.point((9, 3), fill=hexa("1b1b1b"))
    d.rectangle([10, 3, 11, 5], fill=hexa("22252b"))    # bico
    d.rectangle([3, 8, 6, 13], fill=az)                 # cauda
    d.rectangle([5, 9, 6, 10], fill=hexa("f3d03e"))     # peito amarelo
    d.rectangle([6, 10, 8, 12], fill=hexa("4b3b2a"))    # galho/pés


def _tucano(d):
    d.rectangle([4, 3, 8, 10], fill=hexa("1d1d24"))
    d.rectangle([7, 2, 10, 5], fill=hexa("1d1d24"))
    d.rectangle([7, 5, 9, 8], fill=hexa("f4f1ea"))      # peito branco
    d.rectangle([9, 3, 15, 5], fill=hexa("f28a1d"))     # bico grande
    d.rectangle([9, 3, 15, 3], fill=hexa("ffd23f"))
    d.rectangle([14, 4, 15, 5], fill=hexa("c0392b"))
    d.point((9, 3), fill=hexa("f4f1ea"))
    d.rectangle([2, 9, 5, 12], fill=hexa("1d1d24"))     # cauda
    d.rectangle([6, 10, 8, 12], fill=hexa("4b3b2a"))


def _onca(d):
    pel, man = hexa("e6b02e"), hexa("1f1a14")
    d.rectangle([2, 4, 12, 9], fill=pel)                # corpo
    d.rectangle([11, 2, 15, 7], fill=pel)               # cabeça
    d.rectangle([11, 1, 12, 2], fill=pel)
    d.rectangle([14, 1, 15, 2], fill=pel)
    d.point((14, 4), fill=man)
    d.point((15, 6), fill=man)
    d.rectangle([2, 9, 3, 12], fill=pel)
    d.rectangle([10, 9, 11, 12], fill=pel)
    d.rectangle([0, 4, 2, 5], fill=pel)                 # cauda
    d.point((0, 3), fill=man)
    for x, y in ((4, 5), (6, 7), (8, 5), (10, 7), (5, 8), (9, 4)):
        d.point((x, y), fill=man)


ANIMAIS = {"capivara": _capivara, "arara": _arara, "tucano": _tucano, "onca": _onca}


def animais():
    out = {}
    for nome, f in ANIMAIS.items():
        im, d = novo(16, 14)
        f(d)
        # contorno de 1 px
        px = im.load()
        borda = []
        for y in range(im.height):
            for x in range(im.width):
                if px[x, y][3] == 0:
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < im.width and 0 <= ny < im.height and px[nx, ny][3] > 0:
                            borda.append((x, y)); break
        for p in borda:
            px[p] = CONTORNO
        out[nome] = im
        salvar(im, f"animal_{nome}.png")
    return out


# ---------------------------------------------------------------- gaiola
def gaiola(animais_im):
    """Uma gaiola por animal (animal visível por trás das grades)."""
    for nome, an in animais_im.items():
        w, h = 24, 26
        im, d = novo(w, h)
        im.paste(an, (4, 8), an)                         # animal lá dentro
        d = ImageDraw.Draw(im)
        metal, claro = hexa("6b7280"), hexa("c3c9d2")
        d.rectangle([0, 0, w - 1, 2], fill=CONTORNO)    # teto
        d.rectangle([1, 1, w - 2, 1], fill=claro)
        d.rectangle([0, h - 4, w - 1, h - 1], fill=CONTORNO)   # base
        d.rectangle([1, h - 3, w - 2, h - 2], fill=hexa("5a3b22"))
        for x in range(2, w - 1, 4):                     # grades
            d.rectangle([x, 3, x, h - 5], fill=metal)
            d.point((x, 5), fill=claro)
        d.rectangle([0, 3, 0, h - 5], fill=CONTORNO)
        d.rectangle([w - 1, 3, w - 1, h - 5], fill=CONTORNO)
        d.point((w // 2, 0), fill=hexa("ffd23f"))        # cadeado/lâmpada
        salvar(im, f"gaiola_{nome}.png")


# ---------------------------------------------------------------- fogo
PALETA_FOGO = [hexa(c) for c in ("7a1a10", "b8281a", "e8541a", "f98d1f", "ffc83a", "fff0a0")]
MIOLO = hexa("fbb62e")


def fogo(quadros=8, tam=32, esc=2):
    """Faixa vertical de fogo que se repete sem emenda. Sólido à esquerda,
    chamas avançando para a direita."""
    sheet = Image.new("RGBA", (tam * quadros * esc, tam * esc), (0, 0, 0, 0))
    rnd = random.Random(7)
    for f in range(quadros):
        im, _ = novo(tam, tam)
        px = im.load()
        fase = f / quadros
        for y in range(tam):
            t = y / tam
            borda = (19
                     + 5 * math.sin(2 * math.pi * (t - fase))
                     + 3 * math.sin(2 * math.pi * (2 * t + 2 * fase) + 1.0)
                     + 2 * math.sin(2 * math.pi * (4 * t - 3 * fase) + 2.0))
            for x in range(tam):
                prof = borda - x          # quanto dentro do fogo
                if prof < 0:
                    continue
                if prof >= 15:
                    px[x, y] = MIOLO
                    continue
                faixa = prof / 15 * (len(PALETA_FOGO) - 1)
                i = int(faixa)
                # dithering leve entre faixas vizinhas
                if (x + y) % 2 == 0 and faixa - i > 0.5 and i + 1 < len(PALETA_FOGO):
                    i += 1
                px[x, y] = PALETA_FOGO[len(PALETA_FOGO) - 1 - min(i, len(PALETA_FOGO) - 1)] \
                    if False else PALETA_FOGO[min(len(PALETA_FOGO) - 1, int(faixa + (0.5 if (x + y) % 2 == 0 else 0)))]
        # brasas soltas
        for _ in range(5):
            ex = int(borda + 3 + rnd.random() * 5) if False else rnd.randint(24, tam - 1)
            ey = rnd.randrange(tam)
            if px[ex, ey][3] == 0:
                px[ex, ey] = PALETA_FOGO[rnd.choice((4, 5))]
        # inverte a paleta: ponta escura (vermelho) -> centro claro
        sheet.paste(im.resize((tam * esc, tam * esc), Image.NEAREST), (f * tam * esc, 0))
    sheet.save(os.path.join(SAIDA, "fogo_sheet.png"))
    return sheet


def brilho(larg=180, alt=540):
    """Gradiente avermelhado (alfa decrescente) que ilumina o cenário à frente do fogo."""
    im = Image.new("RGBA", (larg, alt), (0, 0, 0, 0))
    px = im.load()
    for x in range(larg):
        a = int(110 * (1 - x / larg) ** 2)
        for y in range(alt):
            px[x, y] = (255, 110, 20, a)
    im.save(os.path.join(SAIDA, "brilho_fogo.png"))


if __name__ == "__main__":
    os.makedirs(SAIDA, exist_ok=True)
    caixote(); espinhos(); barreira()
    an = animais(); gaiola(an)
    fogo(); brilho()
    print("ok")
