"""
Prepara cenários e menu:
  * redimensiona cada cenário para a altura da janela (540 px);
  * cria faixas de transição (crossfade) entre cenários que vão ficar um do
    lado do outro, para não aparecer corte seco;
  * recorta o banner e os botões da arte do menu.

Uso:  python tools/preparar_cenarios.py
"""
import os
from PIL import Image

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ORIG = os.path.join(RAIZ, "arte_original")
SAIDA = os.path.join(RAIZ, "assets", "cenarios")
MENU = os.path.join(RAIZ, "assets", "menu")
ALTURA = 540
FAIXA = 120  # largura da transição

CENARIOS = {"inicial": "cenario.inicial.jpeg", "2": "cenario.2.jpeg", "3": "cenario3.jpeg",
            "4": "cenario4.jpeg", "5": "cenario5.jpeg"}
# pares (a, b): "a" termina e "b" começa
PARES = [("inicial", "2"), ("2", "3"), ("3", "4"), ("4", "5"), ("5", "4"), ("5", "3"),
         ("4", "3"), ("3", "inicial")]


def carregar(nome):
    im = Image.open(os.path.join(ORIG, CENARIOS[nome])).convert("RGB")
    return im.resize((round(im.width * ALTURA / im.height), ALTURA), Image.LANCZOS)


def main():
    os.makedirs(SAIDA, exist_ok=True); os.makedirs(MENU, exist_ok=True)
    cen = {n: carregar(n) for n in CENARIOS}
    for n, im in cen.items():
        corpo = im.crop((FAIXA, 0, im.width - FAIXA, ALTURA))       # miolo sem as bordas
        corpo.save(os.path.join(SAIDA, f"corpo_{n}.png"))
        im.save(os.path.join(SAIDA, f"inteiro_{n}.png"))
        print(n, im.size, "corpo", corpo.size)
    # máscara horizontal: 0 na borda esquerda (só o cenário "a") até 255 na direita (só o "b")
    grad = Image.linear_gradient("L").rotate(90).resize((FAIXA, ALTURA))
    for a, b in PARES:
        fim_a = cen[a].crop((cen[a].width - FAIXA, 0, cen[a].width, ALTURA))
        ini_b = cen[b].crop((0, 0, FAIXA, ALTURA))
        Image.composite(ini_b, fim_a, grad).save(os.path.join(SAIDA, f"trans_{a}_{b}.png"))

    # ---- menu
    m = Image.open(os.path.join(ORIG, "menuinicial.jpeg")).convert("RGB")
    m.crop((0, 0, m.width, 306)).save(os.path.join(MENU, "banner.png"))
    for i, (y0, y1) in enumerate(((326, 392), (401, 467), (476, 545))):
        m.crop((586, y0, 980, y1)).save(os.path.join(MENU, f"botao{i + 1}.png"))


if __name__ == "__main__":
    main()
