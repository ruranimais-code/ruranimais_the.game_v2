"""
"PyGame de mentira", feito com Pillow, SÓ para testar o jogo em um computador
sem tela/sem PyGame (foi usado para gerar as capturas e simular partidas).
No seu computador o jogo usa o PyGame de verdade; este arquivo não é necessário.

Implementa apenas o que o jogo usa: Surface, Rect, draw, font, transform, image,
event, key, mouse, mixer, display e time.

    import pygame_falso; pygame_falso.instalar()   # antes de importar o jogo
"""
import itertools
import sys
import types

from PIL import Image, ImageDraw, ImageFont

FONTE = "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf"   # mesma família da fonte padrão do PyGame


class _Erro(Exception):
    pass


# ------------------------------------------------------------------------ Rect
class Rect:
    def __init__(self, *a):
        if len(a) == 1:
            a = tuple(a[0])
        if len(a) == 2:
            (x, y), (w, h) = a
        else:
            x, y, w, h = a
        self.x, self.y, self.w, self.h = int(x), int(y), int(w), int(h)

    width = property(lambda s: s.w, lambda s, v: setattr(s, "w", v))
    height = property(lambda s: s.h, lambda s, v: setattr(s, "h", v))
    left = property(lambda s: s.x, lambda s, v: setattr(s, "x", v))
    top = property(lambda s: s.y, lambda s, v: setattr(s, "y", v))
    right = property(lambda s: s.x + s.w, lambda s, v: setattr(s, "x", v - s.w))
    bottom = property(lambda s: s.y + s.h, lambda s, v: setattr(s, "y", v - s.h))
    centerx = property(lambda s: s.x + s.w // 2, lambda s, v: setattr(s, "x", v - s.w // 2))
    centery = property(lambda s: s.y + s.h // 2, lambda s, v: setattr(s, "y", v - s.h // 2))
    center = property(lambda s: (s.centerx, s.centery),
                      lambda s, v: (setattr(s, "centerx", v[0]), setattr(s, "centery", v[1])))
    size = property(lambda s: (s.w, s.h))
    topleft = property(lambda s: (s.x, s.y))

    def inflate(self, dx, dy):
        return Rect(self.x - dx // 2, self.y - dy // 2, self.w + dx, self.h + dy)

    def move(self, dx, dy):
        return Rect(self.x + dx, self.y + dy, self.w, self.h)

    def collidepoint(self, *p):
        x, y = p[0] if len(p) == 1 else p
        return self.x <= x < self.x + self.w and self.y <= y < self.y + self.h

    def __iter__(self):
        return iter((self.x, self.y, self.w, self.h))

    def __getitem__(self, i):
        return (self.x, self.y, self.w, self.h)[i]

    def __repr__(self):
        return f"Rect({self.x}, {self.y}, {self.w}, {self.h})"


def _rect(r):
    return tuple(int(v) for v in (r if not isinstance(r, Rect) else tuple(r)))


# --------------------------------------------------------------------- Surface
SRCALPHA = 0x00010000
FULLSCREEN = 0x80000000
SCALED = 0x00000200


class Surface:
    def __init__(self, tam, flags=0, _im=None):
        if _im is not None:
            self.im = _im
        else:
            w, h = int(tam[0]), int(tam[1])
            self.im = Image.new("RGBA", (w, h), (0, 0, 0, 0) if flags & SRCALPHA else (0, 0, 0, 255))
        self._alpha = 255

    def get_width(self): return self.im.width
    def get_height(self): return self.im.height
    def get_size(self): return self.im.size
    def get_rect(self, **kw):
        r = Rect(0, 0, *self.im.size)
        for k, v in kw.items():
            setattr(r, k, v)
        return r
    def copy(self):
        s = Surface(None, _im=self.im.copy()); s._alpha = self._alpha; return s
    def convert(self):
        im = self.im.copy(); im.putalpha(255); return Surface(None, _im=im)
    def convert_alpha(self): return self.copy()
    def set_alpha(self, a): self._alpha = 255 if a is None else int(a)
    def get_alpha(self): return self._alpha

    def fill(self, cor):
        cor = tuple(cor) + ((255,) if len(cor) == 3 else ())
        self.im.paste(cor, (0, 0, *self.im.size))

    def subsurface(self, rect):
        x, y, w, h = _rect(rect)
        return Surface(None, _im=self.im.crop((x, y, x + w, y + h)))

    def blit(self, src, dest, area=None):
        if isinstance(dest, (tuple, list)) and len(dest) == 4:
            dest = dest[:2]
        elif isinstance(dest, Rect):
            dest = dest.topleft
        im = src.im
        if area is not None:
            x, y, w, h = _rect(area)
            im = im.crop((x, y, x + w, y + h))
        if src._alpha < 255:
            im = im.copy()
            a = im.getchannel("A").point(lambda v: v * src._alpha // 255)
            im.putalpha(a)
        dx, dy = int(dest[0]), int(dest[1])
        # recorta o que sai da imagem de destino
        sx0, sy0 = max(0, -dx), max(0, -dy)
        sx1 = min(im.width, self.im.width - dx)
        sy1 = min(im.height, self.im.height - dy)
        if sx1 <= sx0 or sy1 <= sy0:
            return
        if (sx0, sy0, sx1, sy1) != (0, 0, im.width, im.height):
            im = im.crop((sx0, sy0, sx1, sy1))
        self.im.alpha_composite(im, (dx + sx0, dy + sy0))


# ------------------------------------------------------------------------ draw
def _cor(c):
    c = tuple(int(v) for v in c)
    return c if len(c) == 4 else c + (255,)


def _desenhador(s):
    return ImageDraw.Draw(s.im)


class _Draw:
    @staticmethod
    def rect(s, cor, rect, width=0, border_radius=0):
        x, y, w, h = _rect(rect)
        if w <= 0 or h <= 0:
            return
        d, cor = _desenhador(s), _cor(cor)
        xy = [x, y, x + w - 1, y + h - 1]
        kw = dict(fill=cor) if width == 0 else dict(outline=cor, width=width)
        if border_radius:
            d.rounded_rectangle(xy, radius=min(border_radius, w // 2, h // 2), **kw)
        else:
            d.rectangle(xy, **kw)

    @staticmethod
    def ellipse(s, cor, rect, width=0):
        x, y, w, h = _rect(rect)
        kw = dict(fill=_cor(cor)) if width == 0 else dict(outline=_cor(cor), width=width)
        _desenhador(s).ellipse([x, y, x + w - 1, y + h - 1], **kw)

    @staticmethod
    def circle(s, cor, centro, raio, width=0):
        cx, cy = centro
        kw = dict(fill=_cor(cor)) if width == 0 else dict(outline=_cor(cor), width=width)
        _desenhador(s).ellipse([cx - raio, cy - raio, cx + raio, cy + raio], **kw)

    @staticmethod
    def line(s, cor, p0, p1, width=1):
        _desenhador(s).line([tuple(p0), tuple(p1)], fill=_cor(cor), width=width)

    @staticmethod
    def polygon(s, cor, pontos, width=0):
        pts = [tuple(p) for p in pontos]
        d = _desenhador(s)
        if width == 0:
            d.polygon(pts, fill=_cor(cor))
        else:
            d.line(pts + [pts[0]], fill=_cor(cor), width=width, joint="curve")


# ------------------------------------------------------------------------ font
class Font:
    def __init__(self, nome, tam):
        # o PyGame reduz a fonte padrão: tamanho * 0.6875 (ver font.c)
        self.f = ImageFont.truetype(FONTE, max(4, int(tam * 0.6875)))

    def size(self, txt):
        asc, desc = self.f.getmetrics()
        return (int(self.f.getlength(txt)), asc + desc)

    def get_height(self):
        asc, desc = self.f.getmetrics()
        return asc + desc

    def render(self, txt, aa, cor, fundo=None):
        w, h = self.size(txt)
        w, h = max(1, w), max(1, h)
        mask = Image.new("L", (w, h), 0)
        ImageDraw.Draw(mask).text((0, 0), txt, font=self.f, fill=255)
        im = Image.new("RGBA", (w, h), _cor(cor)[:3] + (0,))
        im.putalpha(mask)
        return Surface(None, _im=im)


# ------------------------------------------------------------------- transform
class _Transform:
    @staticmethod
    def scale(s, tam):
        return Surface(None, _im=s.im.resize((int(tam[0]), int(tam[1])), Image.NEAREST))

    @staticmethod
    def smoothscale(s, tam):
        return Surface(None, _im=s.im.resize((int(tam[0]), int(tam[1])), Image.LANCZOS))

    @staticmethod
    def flip(s, x, y):
        im = s.im
        if x:
            im = im.transpose(Image.FLIP_LEFT_RIGHT)
        if y:
            im = im.transpose(Image.FLIP_TOP_BOTTOM)
        return Surface(None, _im=im.copy())


# ------------------------------------------------------------------- image/time
class _Image:
    @staticmethod
    def load(caminho):
        try:
            return Surface(None, _im=Image.open(caminho).convert("RGBA"))
        except FileNotFoundError:
            raise
        except Exception as e:
            raise _Erro(str(e))

    @staticmethod
    def save(s, caminho):
        s.im.convert("RGB").save(caminho)


class _Clock:
    def tick(self, fps=0):
        return int(1000 / fps) if fps else 16


# ----------------------------------------------------------------------- mixer
class _Canal:
    def get_busy(self): return True


class _Som:
    def __init__(self, caminho):
        open(caminho, "rb").close()      # falha se o arquivo não existir, como o de verdade
        self.nome = caminho.replace("\\", "/").split("/")[-1][:-4]

    def set_volume(self, v): pass
    def stop(self): _mixer.log.append(("stop", self.nome))

    def play(self, loops=0):
        _mixer.log.append(("play", self.nome))
        return _Canal()


class _Mixer:
    log = []
    Sound = _Som
    @staticmethod
    def init(*a, **k): pass
    @staticmethod
    def pre_init(*a, **k): pass
    @staticmethod
    def pause(): _mixer.log.append(("pause", None))
    @staticmethod
    def unpause(): _mixer.log.append(("unpause", None))


_mixer = _Mixer


# ------------------------------------------------------------ eventos, teclado
class Event:
    def __init__(self, tipo, **kw):
        self.type = tipo
        self.__dict__.update(kw)


class _Teclas:
    def __init__(self, ativas): self.ativas = ativas
    def __getitem__(self, k): return k in self.ativas


class _Estado:
    fila, pressionadas, pos, quadros = [], set(), (0, 0), 0


def instalar():
    """Coloca este módulo no lugar do 'pygame' para quem for importá-lo depois."""
    m = types.ModuleType("pygame")
    m.error = _Erro
    m.Rect, m.Surface, m.Event = Rect, Surface, Event
    m.SRCALPHA, m.FULLSCREEN, m.SCALED = SRCALPHA, FULLSCREEN, SCALED
    m.draw, m.transform, m.image, m.mixer = _Draw, _Transform, _Image, _Mixer
    m.font = types.SimpleNamespace(Font=Font, SysFont=lambda n, t, **k: Font(None, t))
    m.time = types.SimpleNamespace(Clock=_Clock, get_ticks=lambda: 0)
    m.mouse = types.SimpleNamespace(get_pos=lambda: _Estado.pos, set_visible=lambda v: None)
    m.key = types.SimpleNamespace(get_pressed=lambda: _Teclas(_Estado.pressionadas))
    m.event = types.SimpleNamespace(get=lambda: [_Estado.fila.pop(0) for _ in range(len(_Estado.fila))],
                                    post=lambda e: _Estado.fila.append(e))

    _tela = {}

    def set_mode(tam, flags=0):
        _tela["s"] = Surface(tam, 0)
        return _tela["s"]

    def flip():
        _Estado.quadros += 1

    m.display = types.SimpleNamespace(
        set_mode=set_mode, flip=flip, update=flip, set_caption=lambda *a: None,
        toggle_fullscreen=lambda: 1, get_surface=lambda: _tela["s"], set_icon=lambda *a: None)
    m.init = lambda: (7, 0)
    m.quit = lambda: None

    # tipos de evento e teclas
    for i, nome in enumerate(["QUIT", "KEYDOWN", "KEYUP", "MOUSEMOTION", "MOUSEBUTTONDOWN",
                              "MOUSEBUTTONUP", "WINDOWFOCUSLOST"]):
        setattr(m, nome, 100 + i)
    teclas = ["UP", "DOWN", "LEFT", "RIGHT", "SPACE", "ESCAPE", "RETURN", "KP_ENTER", "BACKSPACE",
              "TAB", "F11"] + list("abcdefghijklmnopqrstuvwxyz")
    for i, nome in enumerate(teclas):
        setattr(m, "K_" + nome, 1000 + i)
    m.estado = _Estado
    sys.modules["pygame"] = m
    return m
