"""
Joga o jogo sozinho (um "robô" aperta as teclas de verdade) usando o PyGame
falso, para testar sem janela, medir a economia da loja e tirar capturas de tela.

Uso:
    python tools/simular.py capturas  PASTA     # salva imagens de todas as telas
    python tools/simular.py bot       [N]       # N partidas completas; mostra estatísticas
"""
import os
import random
import sys

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(RAIZ, "tools"))
sys.path.insert(0, RAIZ)
os.chdir(RAIZ)

import pygame_falso                     # noqa: E402

pg = pygame_falso.instalar()

import config as C                      # noqa: E402
import estatisticas                     # noqa: E402
import main                             # noqa: E402
import skins as SK                      # noqa: E402

DT = 1 / 60


def apertar(jogo, tecla):
    pg.estado.pressionadas.add(tecla)
    jogo.evento(pg.Event(pg.KEYDOWN, key=tecla))


def soltar(jogo, tecla):
    pg.estado.pressionadas.discard(tecla)
    jogo.evento(pg.Event(pg.KEYUP, key=tecla))


def tocar_tecla(jogo, tecla):
    apertar(jogo, tecla)
    soltar(jogo, tecla)


class Robo:
    """Olha o próximo obstáculo e aperta pular / deslizar na hora certa.
    As comidas em arco sobre os espinhos vêm de graça ao pular; as outras ele ignora."""

    def __init__(self, jogo, rnd, erro=0.0):
        self.jogo, self.rnd, self.erro = jogo, rnd, erro
        self.deslizando = False
        self.ignorar = set()
        self._soltar_em = 0

    def passo(self):
        p = self.jogo.partida
        j = p.j
        proximo = None
        for o in p.obstaculos:
            if o.ativo and o.x + o.w > j.x - 40 and id(o) not in self.ignorar:
                if proximo is None or o.x < proximo.x:
                    proximo = o
        if self.deslizando:
            if proximo is None or proximo.tipo != "barreira" or j.x > proximo.x + proximo.w + 60:
                soltar(self.jogo, pg.K_s)
                self.deslizando = False
        if proximo is not None:
            d = proximo.x - j.x
            falha = self.rnd.random() < self.erro
            if ((proximo.tipo == "espinhos" and 60 < d < 105) or
                    (proximo.tipo == "caixote" and 170 < d < 215)) and j.no_chao:
                if falha:
                    self.ignorar.add(id(proximo))
                else:
                    apertar(self.jogo, pg.K_SPACE)
                    self._soltar_em = 40        # segura o pulo (soltar cedo corta o salto)
            elif proximo.tipo == "barreira" and 20 < d < 90 and not self.deslizando and j.no_chao:
                if falha:
                    self.ignorar.add(id(proximo))
                else:
                    apertar(self.jogo, pg.K_s)
                    self.deslizando = True
        if self._soltar_em > 0:
            self._soltar_em -= 1
            if self._soltar_em == 0:
                soltar(self.jogo, pg.K_SPACE)


def novo_jogo(salvar=False):
    tela = pg.display.set_mode((C.LARGURA, C.ALTURA))
    jogo = main.Jogo(tela)
    if not salvar:
        jogo.prog.salvar = lambda: None       # a simulação não mexe no save.json de verdade
    return jogo


def iniciar(jogo, animal="cachorro"):
    """Do menu até a corrida, pelas teclas: Iniciar -> escolher o bichinho -> Enter."""
    assert jogo.estado == "menu", jogo.estado
    tocar_tecla(jogo, pg.K_RETURN)
    assert jogo.estado == "escolha", jogo.estado
    while SK.ANIMAIS[jogo.sel] != animal:
        tocar_tecla(jogo, pg.K_RIGHT)
    tocar_tecla(jogo, pg.K_RETURN)
    assert jogo.estado == "jogando", jogo.estado


def jogar_partida(jogo, rnd, erro=0.0, max_s=300, ao_quadro=None, animal="cachorro"):
    """Joga uma partida inteira. Devolve (metros, comidas, segundos)."""
    iniciar(jogo, animal)
    robo = Robo(jogo, rnd, erro)
    n = 0
    while jogo.estado in ("jogando", "morrendo") and n < max_s * 60:
        if jogo.estado == "jogando":
            robo.passo()
        jogo.atualizar(DT)
        if ao_quadro:
            ao_quadro(jogo, n)
        n += 1
    pg.estado.pressionadas.clear()
    p = jogo.partida
    return p.metros_inteiros, p.comidas_pegas, p.tempo


def sair_do_fim(jogo):
    if jogo.estado == "jogando":              # passou do limite de tempo da simulação
        jogo.voltar_ao_menu()
        return
    jogo.atualizar(1.0)
    tocar_tecla(jogo, pg.K_m)
    assert jogo.estado == "menu", jogo.estado


# ============================================================================ bot
def modo_bot(n):
    rnd = random.Random(1)
    jogo = novo_jogo()
    for i in range(n):
        erro = [0.0, 0.1, 0.25][i % 3]
        animal = SK.ANIMAIS[i % 2]
        m, c, t = jogar_partida(jogo, rnd, erro, animal=animal)
        print(f"partida {i + 1}: {animal:8s} erro={erro:.2f}  {m:5d} m  comidas={c:4d}  {t:4.0f} s  "
              f"batidas={jogo.partida.stats['erros']}  saldo={jogo.prog.moedas}")
        sair_do_fim(jogo)
    d = jogo.prog.dados
    print("partidas:", d["partidas"], "| recorde:", jogo.prog.recorde, "m | saldo:", jogo.prog.moedas,
          "| total de comidas:", d["total_comidas"], "| conquistas:", len(d["conquistas"]), "/",
          len(estatisticas.CONQUISTAS))


# ====================================================================== capturas
def modo_capturas(pasta):
    os.makedirs(pasta, exist_ok=True)
    rnd = random.Random(5)
    jogo = novo_jogo()
    vistos = {}

    def salvar(nome):
        jogo.desenhar()
        pg.image.save(jogo.tela, os.path.join(pasta, nome + ".png"))

    som_original = jogo.som

    def som_espiao(nome):
        vistos[nome] = vistos.get(nome, 0) + 1
        som_original(nome)
    jogo.som = som_espiao

    jogo.atualizar(0.1)
    salvar("01_menu")
    tocar_tecla(jogo, pg.K_RETURN)
    jogo.atualizar(0.2)
    salvar("02_escolha")
    tocar_tecla(jogo, pg.K_ESCAPE)

    feitas = set()
    agenda = {}
    atrasos = {"pulo": 0.15, "deslizar": 0.25, "comida": 0.12, "batida": 0.2}

    def ao_quadro(j, n):
        if n == 25:
            salvar("03_corrida_inicio")
        for nome, atraso in atrasos.items():
            if nome in vistos and nome not in feitas and nome not in agenda:
                agenda[nome] = n + int(atraso * 60)
        for nome, quadro in list(agenda.items()):
            if n >= quadro and nome not in feitas:
                feitas.add(nome)
                salvar(f"04_{nome}")
        if "conquista" in vistos and "toast" not in feitas and j.telas.toasts:
            feitas.add("toast")
            salvar("05_toast_conquista")
        if j.estado == "morrendo" and "m1" not in feitas and j.t_estado > 0.6:
            feitas.add("m1")
            salvar("06_fogo_engole")

    m, c, t = jogar_partida(jogo, rnd, erro=0.2, ao_quadro=ao_quadro, animal="gato")
    print("partida 1 (gato):", m, "m,", c, "comidas,", round(t), "s")
    jogo.atualizar(1.0)
    salvar("07_fim")

    # loja: pelo atalho L da tela de fim (com saldo e sem saldo)
    tocar_tecla(jogo, pg.K_l)
    assert jogo.estado == "loja"
    jogo.atualizar(0.3)
    salvar("08_loja_gato")
    jogo.prog.dados["moedas"] = 150
    tocar_tecla(jogo, pg.K_DOWN)                 # aba do cachorro
    tocar_tecla(jogo, pg.K_RIGHT)
    tocar_tecla(jogo, pg.K_RETURN)               # compra o golden
    jogo.atualizar(0.2)
    salvar("09_loja_compra")
    tocar_tecla(jogo, pg.K_ESCAPE)
    tocar_tecla(jogo, pg.K_m)
    assert jogo.estado == "menu"

    # pausa, conquistas e configurações
    iniciar(jogo, "cachorro")
    for _ in range(150):
        jogo.atualizar(DT)
    tocar_tecla(jogo, pg.K_p)
    assert jogo.estado == "pausa"
    salvar("10_pausa")
    tocar_tecla(jogo, pg.K_ESCAPE)
    jogo.voltar_ao_menu()
    jogo.ir_para("conquistas")
    salvar("11_conquistas")
    jogo.ir_para("config", 1)
    salvar("12_config")
    print("sons tocados:", vistos)
    print("capturas em", pasta)


if __name__ == "__main__":
    modo = sys.argv[1] if len(sys.argv) > 1 else "bot"
    if modo == "capturas":
        modo_capturas(sys.argv[2] if len(sys.argv) > 2 else "capturas")
    else:
        modo_bot(int(sys.argv[2]) if len(sys.argv) > 2 else 3)
