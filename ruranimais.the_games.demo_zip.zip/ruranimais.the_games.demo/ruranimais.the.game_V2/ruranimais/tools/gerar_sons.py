"""
Gera os efeitos sonoros e a música (estilo chiptune) em assets/sons/*.wav.
Tudo sintetizado aqui mesmo, então não depende de nenhum áudio externo.

Uso:  python tools/gerar_sons.py
"""
import os
import wave
import numpy as np

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SAIDA = os.path.join(RAIZ, "assets", "sons")
SR = 22050
rng = np.random.default_rng(3)


def salvar(nome, x):
    x = np.clip(x, -1, 1)
    dados = (x * 32767 * 0.8).astype("<i2")
    with wave.open(os.path.join(SAIDA, nome), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(dados.tobytes())


def t_(d):
    return np.linspace(0, d, int(SR * d), endpoint=False)


def quadrada(f, t, duty=0.5):
    return np.where((t * f) % 1.0 < duty, 1.0, -1.0)


def env(n, ataque=0.01, queda=3.0):
    t = np.linspace(0, 1, n)
    return np.minimum(1, t / max(ataque, 1e-4)) * np.exp(-queda * t)


def varredura(f0, f1, d, duty=0.5, queda=3.0):
    t = t_(d)
    f = np.linspace(f0, f1, t.size)
    fase = np.cumsum(f) / SR
    return np.where(fase % 1.0 < duty, 1.0, -1.0) * env(t.size, 0.005, queda)


def ruido(d, queda=6.0):
    return rng.uniform(-1, 1, int(SR * d)) * env(int(SR * d), 0.002, queda)


def nota(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def musica():
    bpm = 150
    passo = 60 / bpm / 2                      # colcheia
    n_passos = 64
    total = np.zeros(int(SR * passo * n_passos))
    # progressão (graus em MIDI): Am - F - C - G, 2 compassos de 8 colcheias cada
    acordes = [(45, (69, 72, 76)), (41, (65, 69, 72)), (48, (67, 72, 76)), (43, (67, 71, 74))] * 2
    arp = [0, 1, 2, 1, 2, 1, 0, 2]
    melodia = {0: 81, 3: 79, 6: 76, 10: 74, 12: 76, 16: 77, 19: 76, 22: 72, 26: 74, 28: 76,
               32: 79, 35: 76, 38: 72, 42: 76, 44: 79, 48: 74, 51: 71, 54: 74, 58: 76, 60: 79}
    for i in range(n_passos):
        ini = int(i * passo * SR)
        ac = acordes[i // 8]
        base, tons = ac
        d = int(passo * SR)
        t = np.arange(d) / SR
        # baixo
        if i % 2 == 0:
            nb = base if (i // 2) % 4 != 3 else base + 7
            s = quadrada(nota(nb), t, 0.5) * env(d, 0.005, 4) * 0.30
            total[ini:ini + d] += s
        # arpejo
        s = quadrada(nota(tons[arp[i % 8]] - 12 + 12), t, 0.25) * env(d, 0.003, 5) * 0.12
        total[ini:ini + d] += s
        # melodia
        if i in melodia:
            dd = int(passo * 2.5 * SR)
            tt = np.arange(dd) / SR
            s = quadrada(nota(melodia[i]), tt, 0.125) * env(dd, 0.005, 2.5) * 0.17
            fim = min(total.size, ini + dd)
            total[ini:fim] += s[:fim - ini]
        # bateria
        if i % 4 == 0:
            kt = np.arange(d) / SR
            f = 120 * np.exp(-kt * 30) + 40
            total[ini:ini + d] += np.sin(2 * np.pi * np.cumsum(f) / SR) * env(d, 0.001, 8) * 0.45
        if i % 4 == 2:
            total[ini:ini + d] += rng.uniform(-1, 1, d) * env(d, 0.001, 9) * 0.22
        else:
            total[ini:ini + d] += rng.uniform(-1, 1, d) * env(d, 0.001, 30) * 0.06
    total /= max(1.0, np.abs(total).max() * 1.05)
    return total


if __name__ == "__main__":
    os.makedirs(SAIDA, exist_ok=True)
    salvar("pulo.wav", varredura(300, 720, 0.16, 0.5, 4))
    salvar("pouso.wav", varredura(160, 70, 0.08, 0.5, 6) * 0.8)
    salvar("deslizar.wav", ruido(0.28, 4) * 0.5 * np.hanning(int(SR * 0.28)) ** 0.3)
    salvar("batida.wav", ruido(0.35, 5) * 0.8 + varredura(180, 50, 0.35, 0.5, 5) * 0.7)
    # comida: "nhac" curtinho, duas notas subindo (toca muitas vezes por partida, então é breve)
    salvar("comida.wav", np.concatenate([varredura(f, f * 1.03, 0.05, 0.25, 3) for f in (nota(79), nota(86))]))
    # compra: arpejo alegre; negado: buzina grave
    salvar("compra.wav", np.concatenate([varredura(f, f, 0.07, 0.25, 2) for f in (nota(72), nota(76), nota(79), nota(84), nota(88))]))
    salvar("negado.wav", np.concatenate([varredura(f, f * 0.9, 0.09, 0.5, 3) for f in (nota(52), nota(48))]) * 0.8)
    salvar("fim.wav", np.concatenate([varredura(f, f * 0.96, 0.18, 0.5, 2.5) for f in (nota(69), nota(65), nota(62), nota(57))]))
    salvar("menu_move.wav", varredura(520, 520, 0.04, 0.5, 5))
    salvar("menu_ok.wav", np.concatenate([varredura(f, f, 0.06, 0.25, 3) for f in (nota(72), nota(79))]))
    salvar("conquista.wav", np.concatenate([varredura(f, f, 0.08, 0.125, 2) for f in (nota(76), nota(79), nota(83), nota(88))]))
    salvar("musica.wav", musica())
    print("ok")
