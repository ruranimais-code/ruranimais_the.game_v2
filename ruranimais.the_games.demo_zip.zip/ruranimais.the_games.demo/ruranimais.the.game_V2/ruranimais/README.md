# ruranimais - The Game (V2)

Corrida infinita em Python + PyGame. Escolha um **gato** ou um **cachorro**, fuja da parede de
fogo, desvie dos obstáculos e **pegue as comidas** pelo caminho: elas viram moedas para
comprar **skins** (raças e cores) na loja.

## Como rodar

```
pip install pygame
python main.py
```

Precisa de Python 3.9+ e PyGame 2.1+ (usa `pygame.SCALED` e cantos arredondados).

## Controles (mudam em `config.py`, tabela `TECLAS`)

| Ação      | Teclas                                               |
|-----------|------------------------------------------------------|
| Pular     | Seta cima / W / Espaço (segure para pular mais alto) |
| Deslizar  | Seta baixo / S                                       |
| Pausa     | P / Esc                                              |
| Tela cheia| F11                                                  |

Pegar comida não precisa de tecla: é só encostar.
Menus: setas + Enter (ou mouse). Na tela de fim: **R** joga de novo, **L** abre a loja, **M** volta ao menu.
Na loja: setas escolhem a skin, Cima/Baixo ou Tab trocam entre cachorro e gato, Enter compra/equipa.

## Regras

- O bichinho e o fogo correm sozinhos; a velocidade sobe aos poucos com a distância.
- **Caixote**: pule por cima ou pouse nele e pule de novo. **Espinhos**: não pise.
  **Barreira listrada**: pule por cima ou deslize por baixo.
- **Comidas** aparecem em fileiras no chão, em arcos no ar (só pulando), em cima dos caixotes e
  embaixo das barreiras (só deslizando). Cada uma vale 1 moeda e empurra o fogo um pouquinho para trás.
- Cada batida aproxima o fogo; fogo encostou = fim de jogo.
- As moedas ficam salvas (`save.json`) e valem em qualquer partida seguinte.
- Pontuação: **metros corridos** e **comidas pegas**. Cenários: inicial → 2 → 3 → (4 e 5 por 400 m) → 3 → ...

## Skins

| Cachorro (preço) | Gato (preço) |
|---|---|
| Caramelo (inicial) | Gato Cinza (inicial) |
| Golden Retriever (60) | Laranja (60) |
| Pastor Alemão (120) | Gato Preto (120) |
| Dálmata (200) | Siamês (200) |
| Husky (300) | Branco (300) |

A loja inteira custa 1360 moedas. Medindo com um robô que erra de vez em quando, uma partida
rende ~70 a 160 comidas, ou seja, ~10 partidas para comprar tudo.

## Organização do código

| Arquivo | O que faz |
|---|---|
| `main.py` | estados do jogo (menu, escolha, loja, corrida, pausa, fim...), teclado/mouse e laço principal |
| `config.py` | **todos os números ajustáveis**: teclas, pulo, velocidade, fogo, comidas, hitboxes |
| `skins.py` | catálogo de skins: nome na tela e preço |
| `logica.py` | regras: bichinho, colisões, obstáculos, comidas, fogo e geração infinita (não desenha nada) |
| `mundo.py` | desenha o mundo: cenário, bichinho animado, obstáculos, comidas, fogo, partículas |
| `cenario.py` | cenário infinito com o ciclo de fundos e transições suaves |
| `telas.py` | menu, escolha do bichinho, loja, HUD, conquistas, configurações, pausa e fim |
| `estatisticas.py` | recorde, moedas, skins compradas e **conquistas** (salvos em `save.json`) |
| `assets.py` | carrega imagens, animações e sons (arquivo faltando = quadrado colorido, não quebra) |
| `tools/` | geradores de arte/sons e o simulador de testes (não são necessários para jogar) |
| `tests/` | testes automáticos (`python -m pytest -q`) |

## Ajustes comuns

- **Dificuldade**: em `config.py`, `FOGO_PENALIDADE` (castigo por batida), `FOGO_BONUS_COMIDA`
  (quanto cada comida afasta o fogo; com 12 o fogo quase nunca alcançava ninguém), `FOGO_AVANCO`,
  `VELOCIDADE_INICIAL`, `GANHO_POR_METRO`.
- **Preços**: edite a lista em `skins.py`.
- **Nova skin**: acrescente uma linha em `skins.py` e coloque os quadros em
  `assets/animais/<animal>/<id>/` (`correr_0.png`, `parado_0.png`, `pulo_0.png`, `deslize_0.png`...),
  ou acrescente uma troca de cores em `tools/preparar_animais.py` e rode o script.
- **Nova conquista**: uma linha na lista `CONQUISTAS` de `estatisticas.py`, por exemplo
  `("id", "Título", "Descrição", lambda c, t: c["metros"] >= 800)`.
- **Mais comidas**: coloque `comida_6.png` em `assets/objetos/` e aumente `COMIDA_VARIANTES`.

## Artes provisórias (placeholders)

Estas três animações ainda **não têm arte própria**; o jogo usa quadros improvisados
(o quadro de corrida achatado, ou quadros de corrida no lugar do pulo):

- gato: **deslize**
- cachorro: **pulo** e **deslize**

Para trocar, coloque os arquivos `.piskel` em `arte_original_v2/` com os nomes
`gato_deslize*.piskel`, `cachorro_pulo*.piskel` e `cachorro_deslize*.piskel` e rode
`python tools/preparar_animais.py` (ele refaz todas as skins por troca de cores).
Quadros de deslize devem ter no máximo ~50 px de altura (o vão sob a barreira).

## Testes

```
python -m pytest -q
```

Cobrem pulo, caixote, espinhos, barreira, comidas, fogo, geração de fases, ciclo de cenários,
loja, skins, conquistas, arquivos de arte e o fluxo completo das telas.
Sem PyGame instalado, os testes usam `tools/pygame_falso.py` (um substituto feito com Pillow).
`python tools/simular.py bot 6` coloca um robô para jogar e `python tools/simular.py capturas pasta`
salva imagens de todas as telas.
