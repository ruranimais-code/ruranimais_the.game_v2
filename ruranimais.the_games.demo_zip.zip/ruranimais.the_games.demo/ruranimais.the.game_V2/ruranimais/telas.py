"""
Interface do jogo: menu, HUD (placar durante a corrida), conquistas,
configurações, pausa e tela de fim de jogo.

Aqui só se DESENHA. Quem decide em qual tela estamos e o que cada tecla faz é
o main.py. Cada tela que tem opções expõe uma lista de retângulos
(`rets_menu`, `rets_pausa`...) para o main.py também reconhecer cliques do mouse.
"""
import math

import pygame

import config as C
import estatisticas
import skins as SK
from assets import fps_da_animacao, quadro_da_animacao, quadros_do_bichinho

_fontes = {}
_textos = {}


# ---------------------------------------------------------------------- texto
def _fonte(tam):
    if tam not in _fontes:
        _fontes[tam] = pygame.font.Font(None, tam)
    return _fontes[tam]


def _renderizar(txt, tam, cor, contorno):
    f = _fonte(tam)
    base = f.render(txt, True, cor)
    if not contorno:
        return base
    r = max(2, tam // 16)
    s = pygame.Surface((base.get_width() + 2 * r, base.get_height() + 2 * r), pygame.SRCALPHA)
    ctr = f.render(txt, True, contorno)
    for dx in (-r, 0, r):
        for dy in (-r, 0, r):
            if dx or dy:
                s.blit(ctr, (r + dx, r + dy))
    s.blit(base, (r, r))
    return s


def texto(tela, txt, pos, tam=28, cor=C.COR_TINTA, centro=False, direita=False, contorno=None):
    """Escreve `txt`. `pos` é o canto superior esquerdo; com centro=True é o centro;
    com direita=True é o canto superior direito."""
    chave = (txt, tam, cor, contorno)
    surf = _textos.get(chave)
    if surf is None:
        if len(_textos) > 400:
            _textos.clear()
        surf = _textos[chave] = _renderizar(txt, tam, cor, contorno)
    x, y = pos
    if centro:
        x, y = x - surf.get_width() // 2, y - surf.get_height() // 2
    elif direita:
        x -= surf.get_width()
    tela.blit(surf, (int(x), int(y)))
    return surf.get_width()


def largura_texto(txt, tam):
    return _fonte(tam).size(txt)[0]


# --------------------------------------------------------------------- formas
_paineis = {}


def painel(tela, rect, cor=C.COR_CREME, borda=C.COR_TINTA, alpha=255, raio=8, espessura=3):
    r = pygame.Rect(rect)
    chave = (r.size, cor, borda, alpha, raio, espessura)
    s = _paineis.get(chave)
    if s is None:
        s = pygame.Surface(r.size, pygame.SRCALPHA)
        pygame.draw.rect(s, (*cor, alpha), s.get_rect(), border_radius=raio)
        if espessura:
            pygame.draw.rect(s, (*borda, 255), s.get_rect(), espessura, border_radius=raio)
        _paineis[chave] = s
    tela.blit(s, r.topleft)


def estrela(tela, cx, cy, raio, cor, borda=C.COR_TINTA):
    pts = []
    for i in range(10):
        ang = -math.pi / 2 + i * math.pi / 5
        r = raio if i % 2 == 0 else raio * 0.45
        pts.append((cx + r * math.cos(ang), cy + r * math.sin(ang)))
    pygame.draw.polygon(tela, cor, pts)
    if borda:
        pygame.draw.polygon(tela, borda, pts, 2)


def cadeado(tela, cx, cy, tam, cor=(120, 110, 130)):
    w = tam
    pygame.draw.rect(tela, cor, (cx - w // 2, cy - w // 8, w, int(w * 0.75)), border_radius=3)
    pygame.draw.rect(tela, cor, (cx - w // 3, cy - w // 2 - 2, 2 * w // 3, int(w * 0.8)), 3,
                     border_radius=w // 3)
    pygame.draw.rect(tela, (60, 55, 70), (cx - 2, cy + w // 8, 4, w // 4))


def triangulo(tela, x, y, tam, cor, direita=True):
    if direita:
        pts = [(x, y - tam), (x + tam * 1.3, y), (x, y + tam)]
    else:
        pts = [(x, y - tam), (x - tam * 1.3, y), (x, y + tam)]
    pygame.draw.polygon(tela, cor, pts)
    pygame.draw.polygon(tela, C.COR_TINTA, pts, 2)


def _degrade(largura, altura, c1, c2):
    s = pygame.Surface((largura, altura))
    for y in range(altura):
        f = y / max(1, altura - 1)
        cor = tuple(int(c1[i] + (c2[i] - c1[i]) * f) for i in range(3))
        pygame.draw.line(s, cor, (0, y), (largura, y))
    return s


def _escala(surf, fator):
    return pygame.transform.scale(surf, (max(1, int(surf.get_width() * fator)),
                                         max(1, int(surf.get_height() * fator))))


# ------------------------------------------------------------------- a classe
class Telas:
    def __init__(self, imagens):
        self.img = imagens
        L, A = C.LARGURA, C.ALTURA

        # ---- menu
        b = imagens.banner
        self.banner = pygame.transform.smoothscale(b, (L, round(b.get_height() * L / b.get_width())))
        bw, bh = 355, 59                       # botões reduzidos para caber os 4 (Iniciar, Loja, Conquistas, Config.)
        self.botoes = [pygame.transform.smoothscale(b, (bw, bh)) for b in imagens.botoes]
        bx = (L - bw) // 2
        self.rets_menu = [pygame.Rect(bx, 204 + i * 67, bw, bh) for i in range(4)]
        self.veu_botao = pygame.Surface((bw, bh), pygame.SRCALPHA)
        self.veu_botao.fill((233, 208, 156, 110))
        self.fundo_menu = _degrade(L, A, (249, 237, 199), (226, 172, 112))
        pygame.draw.rect(self.fundo_menu, C.COR_CREME, (150, 0, L - 300, A))

        # ---- telas secundárias (conquistas, configurações)
        self.fundo_sec = _degrade(L, A, (249, 237, 199), (236, 205, 150))

        # ---- escurecimento atrás de pausa e fim
        self.escuro = pygame.Surface((L, A), pygame.SRCALPHA)
        self.escuro.fill((25, 14, 30, 150))

        # ---- retângulos de opções
        self.rets_pausa = [pygame.Rect(L // 2 - 140, 205 + i * 56, 280, 46) for i in range(3)]
        self.rets_fim = [pygame.Rect(L // 2 - 225, 436, 215, 48), pygame.Rect(L // 2 + 10, 436, 215, 48)]
        self.rets_config = [pygame.Rect(130, 132 + i * 58, 410, 46) for i in range(5)]
        # escolha do bichinho: um cartão para cada animal
        n = len(SK.ANIMAIS)
        self.rets_escolha = [pygame.Rect(L // 2 - 20 - 340 + i * 360, 100, 340, 372) for i in range(n)]
        # loja: abas (cachorro/gato) e cartões das skins
        self.rets_abas = [pygame.Rect(40 + i * 210, 92, 200, 40) for i in range(n)]
        self.rets_loja = [pygame.Rect(40 + i * 178, 146, 168, 300) for i in range(5)]

        # ---- dica de teclas (aparece no começo da corrida)
        self.dica = self._montar_dica()

        # ---- cartão de conquista (toast)
        self.toasts = []            # [titulo, tempo_restante]
        self._icones = {}
        self._ampliados = {}

    def icone_comida(self, fator, variante=0):
        """Miniatura da comida (em cache para não redimensionar a cada quadro)."""
        chave = (variante, fator)
        if chave not in self._icones:
            self._icones[chave] = _escala(self.img.comidas[variante], fator)
        return self._icones[chave]

    def _grande(self, quadro, fator):
        """Quadro do bichinho ampliado (em cache)."""
        chave = (id(quadro), fator)
        if chave not in self._ampliados:
            self._ampliados[chave] = _escala(quadro, fator)
        return self._ampliados[chave]

    # ============================================================== MENU
    def desenhar_menu(self, tela, sel, t, recorde):
        tela.blit(self.fundo_menu, (0, 0))
        tela.blit(self.banner, (0, 0))
        for i, (r, img) in enumerate(zip(self.rets_menu, self.botoes)):
            tela.blit(img, r.topleft)
            if i != sel:
                tela.blit(self.veu_botao, r.topleft)
        r = self.rets_menu[sel]
        pygame.draw.rect(tela, C.COR_DESTAQUE, r.inflate(10, 10), 4, border_radius=6)
        balanco = int(4 * math.sin(t * 7))
        triangulo(tela, r.left - 44 + balanco, r.centery, 12, C.COR_LARANJA, True)
        triangulo(tela, r.right + 44 - balanco, r.centery, 12, C.COR_LARANJA, False)

        if recorde > 0:
            texto(tela, f"Recorde: {recorde} m", (C.LARGURA // 2, 488), 32, C.COR_VERDE_ESC, centro=True)
        texto(tela, "Setas: escolher   Enter: confirmar   F11: tela cheia",
              (C.LARGURA // 2, 516), 22, (110, 80, 50), centro=True)

    # ======================================================= TELA SECUNDÁRIA
    def _cabecalho(self, tela, titulo, direita=None):
        tela.blit(self.fundo_sec, (0, 0))
        pygame.draw.rect(tela, C.COR_VERDE, (0, 0, C.LARGURA, 78))
        pygame.draw.rect(tela, C.COR_VERDE_ESC, (0, 74, C.LARGURA, 6))
        for x in range(14, C.LARGURA, 28):
            pygame.draw.circle(tela, C.COR_CREME, (x, 8), 3)
            pygame.draw.circle(tela, C.COR_CREME, (x, 70), 3)
        texto(tela, titulo, (36, 24), 52, C.COR_CREME, contorno=C.COR_VERDE_ESC)
        if direita:
            texto(tela, direita, (C.LARGURA - 36, 30), 40, C.COR_DESTAQUE, direita=True,
                  contorno=C.COR_VERDE_ESC)

    # ============================================================ CONQUISTAS
    def desenhar_conquistas(self, tela, prog, t):
        total = len(estatisticas.CONQUISTAS)
        feitas = sum(1 for c in estatisticas.CONQUISTAS if prog.conquistada(c[0]))
        self._cabecalho(tela, "Conquistas", f"{feitas} / {total}")
        por_coluna = (total + 1) // 2          # 16 conquistas = 8 por coluna
        for i, (id_, titulo, desc, _) in enumerate(estatisticas.CONQUISTAS):
            col, lin = divmod(i, por_coluna)
            r = pygame.Rect(34 + col * 462, 90 + lin * 49, 432, 44)
            ganha = prog.conquistada(id_)
            if ganha:
                painel(tela, r, C.COR_CREME, C.COR_TINTA)
                estrela(tela, r.x + 26, r.centery, 14, C.COR_DESTAQUE)
                texto(tela, titulo, (r.x + 54, r.y + 4), 27, C.COR_TINTA)
                texto(tela, desc, (r.x + 54, r.y + 24), 19, (90, 70, 60))
            else:
                painel(tela, r, (226, 214, 184), (140, 125, 110))
                cadeado(tela, r.x + 26, r.centery + 2, 18)
                texto(tela, titulo, (r.x + 54, r.y + 4), 27, (130, 115, 105))
                texto(tela, desc, (r.x + 54, r.y + 24), 19, (150, 135, 120))
        d = prog.dados
        km = d["total_metros"] / 1000
        linha = (f"Partidas: {d['partidas']}     Distância total: {km:.1f} km     "
                 f"Comidas: {d['total_comidas']}     Recorde: {d['recorde_metros']} m")
        texto(tela, linha, (C.LARGURA // 2, 492), 26, C.COR_VERDE_ESC, centro=True)
        texto(tela, "Esc: voltar", (C.LARGURA // 2, 518), 22, (110, 80, 50), centro=True)

    # ============================================================ CONFIG
    def desenhar_config(self, tela, sel, prog, tela_cheia, confirmar_apagar, t):
        self._cabecalho(tela, "Configurações")
        d = prog.dados
        itens = [("Música", "LIGADA" if d["musica"] else "DESLIGADA"),
                 ("Efeitos sonoros", "LIGADOS" if d["efeitos"] else "DESLIGADOS"),
                 ("Tela cheia", "SIM" if tela_cheia else "NÃO"),
                 ("Apagar progresso", "Enter de novo para confirmar" if confirmar_apagar else ""),
                 ("Voltar", "")]
        for i, (r, (nome, valor)) in enumerate(zip(self.rets_config, itens)):
            ativo = i == sel
            perigo = i == 3 and confirmar_apagar
            painel(tela, r, (255, 246, 222) if ativo else C.COR_CREME,
                   C.COR_VERMELHO if perigo else C.COR_TINTA)
            texto(tela, nome, (r.x + 18, r.y + 12), 30, C.COR_TINTA)
            if valor:
                cor = C.COR_VERMELHO if perigo else C.COR_VERDE_ESC
                texto(tela, valor, (r.right - 16, r.y + (15 if perigo else 11)), 22 if perigo else 30,
                      cor, direita=True)
            if ativo:
                pygame.draw.rect(tela, C.COR_DESTAQUE, r.inflate(8, 8), 4, border_radius=8)
                triangulo(tela, r.left - 26 + int(3 * math.sin(t * 7)), r.centery, 9, C.COR_LARANJA)

        caixa = pygame.Rect(580, 132, 330, 288)
        painel(tela, caixa, C.COR_CREME, C.COR_TINTA)
        texto(tela, "Controles", (caixa.centerx, caixa.y + 24), 34, C.COR_VERDE_ESC, centro=True)
        linhas = [("Pular", "pular"), ("Deslizar", "deslizar"), ("Pausa", "pausa")]
        y = caixa.y + 56
        for rotulo, chave in linhas:
            texto(tela, rotulo, (caixa.x + 18, y), 26, C.COR_LARANJA)
            texto(tela, C.NOMES_TECLAS[chave], (caixa.x + 18, y + 22), 24, C.COR_TINTA)
            y += 56
        texto(tela, "Pegar comidas: é só encostar!", (caixa.x + 18, y), 24, C.COR_VERDE_ESC)
        texto(tela, "Setas: escolher   Enter: mudar   Esc: voltar", (C.LARGURA // 2, 504), 22,
              (110, 80, 50), centro=True)

    # ================================================================ HUD
    def desenhar_hud(self, tela, partida, prog, t):
        metros = partida.metros_inteiros
        recorde = max(prog.recorde, metros)
        # ---- esquerda: distância
        painel(tela, (12, 12, 196, 84), C.COR_CREME, C.COR_TINTA, alpha=225)
        texto(tela, f"{metros} m", (26, 18), 54, C.COR_TINTA)
        cor_rec = C.COR_LARANJA if metros >= prog.recorde and metros > 0 else (100, 80, 70)
        texto(tela, f"Recorde {recorde} m", (26, 66), 24, cor_rec)

        # ---- direita: comidas desta corrida e saldo total
        painel(tela, (C.LARGURA - 208, 12, 196, 84), C.COR_CREME, C.COR_TINTA, alpha=225)
        ultima = partida.lista_comidas[-1] if partida.lista_comidas else 0
        tela.blit(self.icone_comida(1.0, ultima), (C.LARGURA - 202, 12))
        texto(tela, str(partida.comidas_pegas), (C.LARGURA - 24, 12), 54, C.COR_TINTA, direita=True)
        texto(tela, f"Total: {prog.moedas + partida.moedas}", (C.LARGURA - 194, 62), 24, (100, 80, 70))

        # ---- centro: barra de perigo (distância do fogo)
        self._barra_fogo(tela, partida, t)

        # ---- dicas de controle no começo da corrida
        if partida.tempo < 7.0:
            a = 255 if partida.tempo < 6.0 else int(255 * (7.0 - partida.tempo))
            self.dica.set_alpha(a)
            tela.blit(self.dica, ((C.LARGURA - self.dica.get_width()) // 2, C.ALTURA - 62))

    def _barra_fogo(self, tela, partida, t):
        w, h = 240, 18
        x, y = (C.LARGURA - w) // 2, 24
        frac = (partida.dist_fogo - C.FOGO_DISTANCIA_MORTE) / (C.FOGO_DIST_MAXIMA - C.FOGO_DISTANCIA_MORTE)
        frac = max(0.0, min(1.0, frac))
        perigo = frac < 0.3
        painel(tela, (x - 62, y - 10, w + 74, h + 20), C.COR_CREME, C.COR_VERMELHO if perigo else C.COR_TINTA,
               alpha=225)
        texto(tela, "FOGO", (x - 52, y - 1), 26, C.COR_VERMELHO)
        pygame.draw.rect(tela, (120, 100, 90), (x + 8, y, w, h), border_radius=5)
        cor = C.COR_VERDE if frac > 0.55 else (C.COR_DESTAQUE if frac > 0.3 else C.COR_VERMELHO)
        if perigo and int(t * 8) % 2:
            cor = (255, 120, 90)
        pygame.draw.rect(tela, cor, (x + 8, y, max(4, int(w * frac)), h), border_radius=5)
        pygame.draw.rect(tela, C.COR_TINTA, (x + 8, y, w, h), 2, border_radius=5)

    def _montar_dica(self):
        itens = [("Pular", C.NOMES_TECLAS["pular"]), ("Deslizar", C.NOMES_TECLAS["deslizar"]),
                 ("Pegar comidas", "é só encostar!")]
        larg = 880
        s = pygame.Surface((larg, 52), pygame.SRCALPHA)
        painel(s, (0, 0, larg, 52), C.COR_CREME, C.COR_TINTA, alpha=225)
        passo = larg // len(itens)
        for i, (nome, teclas) in enumerate(itens):
            cx = passo * i + passo // 2
            texto(s, nome, (cx, 16), 24, C.COR_LARANJA, centro=True)
            texto(s, teclas, (cx, 37), 22, C.COR_TINTA, centro=True)
        return s

    # ============================================================== TOASTS
    def novo_toast(self, titulo):
        self.toasts.append([titulo, 3.2])

    def atualizar_toasts(self, dt):
        if self.toasts:
            self.toasts[0][1] -= dt
            if self.toasts[0][1] <= 0:
                self.toasts.pop(0)

    def desenhar_toasts(self, tela, topo=False):
        """Aviso de conquista. Na corrida aparece embaixo; nas telas de menu, no topo."""
        if not self.toasts:
            return
        titulo, resta = self.toasts[0]
        # entra nos primeiros 0,3 s e sai nos últimos 0,3 s
        desloca = int(max(0.0, min(1.0, resta / 0.3, (3.2 - resta) / 0.3)) * 78)
        r = pygame.Rect(0, 0, 400, 66)
        r.centerx = C.LARGURA // 2
        r.y = (desloca - 70) if topo else (C.ALTURA - desloca - 4)
        painel(tela, r, C.COR_CREME, C.COR_LARANJA, espessura=4)
        estrela(tela, r.x + 36, r.centery, 20, C.COR_DESTAQUE)
        texto(tela, "Conquista desbloqueada!", (r.x + 70, r.y + 10), 24, C.COR_LARANJA)
        texto(tela, titulo, (r.x + 70, r.y + 31), 30, C.COR_TINTA)

    # =============================================================== PAUSA
    def desenhar_pausa(self, tela, sel, t):
        tela.blit(self.escuro, (0, 0))
        painel(tela, (C.LARGURA // 2 - 190, 120, 380, 300), C.COR_CREME, C.COR_TINTA)
        texto(tela, "PAUSADO", (C.LARGURA // 2, 164), 64, C.COR_VERDE_ESC, centro=True)
        nomes = ("Continuar", "Reiniciar", "Menu principal")
        for i, (r, nome) in enumerate(zip(self.rets_pausa, nomes)):
            ativo = i == sel
            painel(tela, r, (255, 246, 222) if ativo else (240, 226, 190), C.COR_TINTA)
            texto(tela, nome, r.center, 32, C.COR_TINTA, centro=True)
            if ativo:
                pygame.draw.rect(tela, C.COR_DESTAQUE, r.inflate(8, 8), 4, border_radius=8)
                triangulo(tela, r.left - 22 + int(3 * math.sin(t * 7)), r.centery, 9, C.COR_LARANJA)

    # ================================================================= FIM
    def desenhar_fim(self, tela, sel, res, t):
        tela.blit(self.escuro, (0, 0))
        painel(tela, (C.LARGURA // 2 - 270, 24, 540, 480), C.COR_CREME, C.COR_TINTA)
        texto(tela, "FIM DE JOGO", (C.LARGURA // 2, 74), 70, C.COR_VERMELHO, centro=True,
              contorno=C.COR_CREME_ESC)
        texto(tela, "você correu", (C.LARGURA // 2, 126), 26, (100, 80, 70), centro=True)
        texto(tela, f"{res['metros']} m", (C.LARGURA // 2, 176), 100, C.COR_TINTA, centro=True)
        if res["novo_recorde"]:
            cor = C.COR_LARANJA if int(t * 4) % 2 else C.COR_VERMELHO
            texto(tela, "NOVO RECORDE!", (C.LARGURA // 2, 232), 40, cor, centro=True)
        else:
            texto(tela, f"Recorde: {res['recorde']} m", (C.LARGURA // 2, 232), 32,
                  C.COR_VERDE_ESC, centro=True)

        # comidas desta corrida e saldo
        ic = self.icone_comida(1.0, 0)
        x0 = C.LARGURA // 2 - 120
        tela.blit(ic, (x0, 262))
        texto(tela, f"x {res['comidas']}", (x0 + 52, 270), 46, C.COR_TINTA)
        texto(tela, f"Saldo: {res['saldo']}", (C.LARGURA // 2 + 40, 276), 34, C.COR_VERDE_ESC)
        if res["comidas"] == 0:
            texto(tela, "Nenhuma comida desta vez: elas valem skins na loja!", (C.LARGURA // 2, 322), 24,
                  (110, 90, 80), centro=True)

        # conquistas desta partida
        novas = res["novas"]
        if novas:
            y = 340
            for titulo in novas[:2]:
                estrela(tela, C.LARGURA // 2 - largura_texto(titulo, 28) // 2 - 22, y + 8, 10, C.COR_DESTAQUE)
                texto(tela, titulo, (C.LARGURA // 2, y + 8), 28, C.COR_LARANJA, centro=True)
                y += 26
            if len(novas) > 2:
                texto(tela, f"+{len(novas) - 2} conquista(s)", (C.LARGURA // 2, y + 8), 22,
                      C.COR_LARANJA, centro=True)

        for i, (r, nome) in enumerate(zip(self.rets_fim, ("Jogar de novo", "Menu principal"))):
            ativo = i == sel
            painel(tela, r, (255, 246, 222) if ativo else (240, 226, 190), C.COR_TINTA)
            texto(tela, nome, r.center, 30, C.COR_TINTA, centro=True)
            if ativo:
                pygame.draw.rect(tela, C.COR_DESTAQUE, r.inflate(8, 8), 4, border_radius=8)
        texto(tela, "R: jogar de novo   M: menu   L: loja", (C.LARGURA // 2, 521), 22,
              (225, 215, 200), centro=True)

    # ============================================================= ESCOLHA
    def desenhar_escolha(self, tela, sel, prog, t):
        """Antes de começar: escolher entre cachorro e gato."""
        self._cabecalho(tela, "Escolha seu companheiro")
        for i, (animal, r) in enumerate(zip(SK.ANIMAIS, self.rets_escolha)):
            ativo = i == sel
            painel(tela, r, (255, 246, 222) if ativo else C.COR_CREME, C.COR_TINTA)
            skin = prog.skin_atual(animal)
            q = quadros_do_bichinho(self.img, animal, skin)["parado"]
            quadro = quadro_da_animacao(q, t + i * 0.37, fps_da_animacao(self.img, animal, "parado"))
            pulo = int(abs(math.sin(t * 5)) * 10) if ativo else 0          # quem está escolhido dá pulinhos
            spr = self._grande(quadro, 2)
            tela.blit(spr, (r.centerx - spr.get_width() // 2, r.y + 16 - pulo))
            texto(tela, SK.NOME_ANIMAL[animal], (r.centerx, r.y + 296), 44, C.COR_TINTA, centro=True)
            nome = SK.info(animal, skin)[1]
            texto(tela, nome, (r.centerx, r.y + 330), 28, C.COR_LARANJA, centro=True)
            texto(tela, f"Skins: {prog.qtd_skins(animal)}/{len(SK.lista(animal))}", (r.centerx, r.y + 354), 20,
                  (110, 90, 80), centro=True)
            if ativo:
                pygame.draw.rect(tela, C.COR_DESTAQUE, r.inflate(10, 10), 5, border_radius=10)
        texto(tela, "Setas: escolher   Enter: jogar   L: loja   Esc: voltar", (C.LARGURA // 2, 504), 22,
              (110, 80, 50), centro=True)

    # ================================================================ LOJA
    def desenhar_loja(self, tela, aba, sel, prog, msg, t):
        """Loja de skins. `aba` = índice do animal; `sel` = skin selecionada; msg = (texto, cor)."""
        self._cabecalho(tela, "Loja")
        # saldo (canto direito do cabeçalho)
        ic = self.icone_comida(0.9, 0)
        txt = str(prog.moedas)
        w = largura_texto(txt, 46)
        tela.blit(ic, (C.LARGURA - 36 - w - ic.get_width() - 8, 14))
        texto(tela, txt, (C.LARGURA - 36, 26), 46, C.COR_DESTAQUE, direita=True, contorno=C.COR_VERDE_ESC)

        # abas
        for i, (animal, r) in enumerate(zip(SK.ANIMAIS, self.rets_abas)):
            ativa = i == aba
            painel(tela, r, C.COR_CREME if ativa else (228, 205, 160), C.COR_TINTA if ativa else (140, 120, 100))
            texto(tela, SK.NOME_ANIMAL[animal] + f"  {prog.qtd_skins(animal)}/{len(SK.lista(animal))}", r.center, 28,
                  C.COR_TINTA if ativa else (130, 110, 90), centro=True)

        animal = SK.ANIMAIS[aba]
        for i, ((id_, nome, preco), r) in enumerate(zip(SK.lista(animal), self.rets_loja)):
            ativo = i == sel
            tem = prog.possui(animal, id_)
            equipada = prog.skin_atual(animal) == id_
            pode = prog.moedas >= preco
            painel(tela, r, (255, 246, 222) if ativo else C.COR_CREME,
                   C.COR_VERDE if equipada else C.COR_TINTA, espessura=4 if equipada else 3)
            q = quadros_do_bichinho(self.img, animal, id_)["parado"]
            quadro = quadro_da_animacao(q, t + i * 0.3, fps_da_animacao(self.img, animal, "parado"))
            tela.blit(quadro, (r.centerx - quadro.get_width() // 2, r.y + 10))
            texto(tela, nome, (r.centerx, r.y + 156), 26 if len(nome) <= 12 else 21, C.COR_TINTA, centro=True)
            btn = pygame.Rect(r.x + 14, r.y + 190, r.w - 28, 50)
            if equipada:
                painel(tela, btn, C.COR_VERDE, C.COR_VERDE_ESC)
                texto(tela, "EQUIPADA", btn.center, 26, C.COR_CREME, centro=True)
            elif tem:
                painel(tela, btn, C.COR_DESTAQUE, C.COR_TINTA)
                texto(tela, "Equipar", btn.center, 28, C.COR_TINTA, centro=True)
            else:
                painel(tela, btn, C.COR_CREME_ESC if pode else (214, 200, 190), C.COR_TINTA if pode else (150, 130, 120))
                icp = self.icone_comida(0.6, 0)
                texto_p = str(preco)
                wp = largura_texto(texto_p, 34)
                x0 = btn.centerx - (wp + icp.get_width() + 6) // 2
                tela.blit(icp, (x0, btn.centery - icp.get_height() // 2))
                texto(tela, texto_p, (x0 + icp.get_width() + 6, btn.centery - 10), 34,
                      C.COR_TINTA if pode else C.COR_VERMELHO)
                cadeado(tela, r.right - 22, r.y + 22, 16)
            if not tem:
                texto(tela, "Comprar" if pode else f"Faltam {preco - prog.moedas}", (r.centerx, r.y + 262), 22,
                      C.COR_VERDE_ESC if pode else C.COR_VERMELHO, centro=True)
            if ativo:
                pygame.draw.rect(tela, C.COR_DESTAQUE, r.inflate(10, 10), 5, border_radius=10)
        if msg:
            texto(tela, msg[0], (C.LARGURA // 2, 474), 30, msg[1], centro=True)
        texto(tela, "Setas: escolher   Cima/Baixo ou Tab: cachorro/gato   Enter: comprar ou equipar   Esc: voltar",
              (C.LARGURA // 2, 514), 20, (110, 80, 50), centro=True)
