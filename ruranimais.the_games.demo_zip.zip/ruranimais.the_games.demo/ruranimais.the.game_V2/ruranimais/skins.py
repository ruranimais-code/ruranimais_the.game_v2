"""
Catálogo de bichinhos e skins da loja.

Para criar uma skin nova:
  1. coloque os quadros em assets/animais/<animal>/<id>/ (correr_0.png, pulo_0.png, ...)
     ou acrescente uma troca de cores em tools/preparar_animais.py e rode o script;
  2. acrescente uma linha na lista do animal aqui: (id, nome na tela, preço em comidas).
A primeira skin de cada animal é a inicial (preço 0, já vem desbloqueada).
"""

ANIMAIS = ("cachorro", "gato")
NOME_ANIMAL = {"cachorro": "Cachorro", "gato": "Gato"}

SKINS = {
    "cachorro": [
        ("caramelo", "Caramelo", 0),
        ("golden", "Golden Retriever", 60),
        ("pastor", "Pastor Alemão", 120),
        ("dalmata", "Dálmata", 200),
        ("husky", "Husky", 300),
    ],
    "gato": [
        ("cinza", "Gato Cinza", 0),
        ("laranja", "Laranja", 60),
        ("preto", "Gato Preto", 120),
        ("siames", "Siamês", 200),
        ("branco", "Branco", 300),
    ],
}


def lista(animal):
    return SKINS[animal]


def inicial(animal):
    return SKINS[animal][0][0]


def info(animal, skin):
    """(id, nome, preço) da skin, ou None se não existir."""
    for s in SKINS[animal]:
        if s[0] == skin:
            return s
    return None


def chave(animal, skin):
    return f"{animal}/{skin}"


def todas_as_chaves(animal=None):
    animais = (animal,) if animal else ANIMAIS
    return [chave(a, s[0]) for a in animais for s in SKINS[a]]
