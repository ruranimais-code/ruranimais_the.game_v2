"""Usa o PyGame de verdade se estiver instalado; senão, o PyGame falso (tools/pygame_falso.py)."""
import os
import sys

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
sys.path.insert(0, os.path.join(RAIZ, "tools"))
os.chdir(RAIZ)

try:
    import pygame                               # noqa: F401
    USANDO_FALSO = False
except ImportError:
    import pygame_falso
    pygame_falso.instalar()
    USANDO_FALSO = True
