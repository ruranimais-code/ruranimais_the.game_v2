"""Recorde, moedas, loja de skins e conquistas."""
import pytest

import estatisticas
import skins as SK
from logica import Partida


@pytest.fixture
def prog(tmp_path, monkeypatch):
    monkeypatch.setattr(estatisticas, "ARQUIVO", str(tmp_path / "save.json"))
    return estatisticas.Progresso()


def partida_com(metros=0, comidas=0, pulos=0):
    p = Partida(semente=1)
    p.j.x = metros * 64
    p.stats.update(comidas=comidas, pulos=pulos)
    p.comidas_pegas = comidas
    return p


def ganhar(prog, moedas):
    prog.dados["moedas"] += moedas


# ------------------------------------------------------------ recorde e saldo
def test_recorde_so_sobe(prog):
    novo, _ = prog.registrar_partida(partida_com(300))
    assert novo and prog.recorde == 300
    novo, _ = prog.registrar_partida(partida_com(100))
    assert not novo and prog.recorde == 300
    assert prog.dados["partidas"] == 2 and prog.dados["total_metros"] == 400


def test_comidas_viram_moedas(prog):
    prog.registrar_partida(partida_com(50, comidas=12))
    prog.registrar_partida(partida_com(50, comidas=8))
    assert prog.moedas == 20 and prog.dados["total_comidas"] == 20
    assert prog.dados["recorde_comidas"] == 12


def test_salva_e_recarrega(prog):
    prog.registrar_partida(partida_com(250, comidas=7))
    ganhar(prog, 0)
    outro = estatisticas.Progresso()
    assert outro.recorde == 250 and outro.moedas == 7


def test_arquivo_corrompido_nao_quebra(tmp_path, monkeypatch):
    f = tmp_path / "save.json"
    f.write_text("{isso não é json")
    monkeypatch.setattr(estatisticas, "ARQUIVO", str(f))
    p = estatisticas.Progresso()
    assert p.recorde == 0 and p.moedas == 0


def test_save_adulterado_e_corrigido(tmp_path, monkeypatch):
    f = tmp_path / "save.json"
    f.write_text('{"moedas": -50, "animal": "dragao", "skins": ["cachorro/inexistente"], '
                 '"skin_ativa": {"gato": "branco"}}')
    monkeypatch.setattr(estatisticas, "ARQUIVO", str(f))
    p = estatisticas.Progresso()
    assert p.moedas == 0 and p.dados["animal"] in SK.ANIMAIS
    assert p.skin_atual("gato") == SK.inicial("gato")          # "branco" não foi comprada
    assert "cachorro/inexistente" not in p.dados["skins"]


# --------------------------------------------------------------------- loja
def test_comeca_com_a_skin_inicial_de_cada_animal(prog):
    for a in SK.ANIMAIS:
        assert prog.possui(a, SK.inicial(a)) and prog.skin_atual(a) == SK.inicial(a)
        assert prog.qtd_skins(a) == 1


def test_comprar_desconta_e_equipa(prog):
    ganhar(prog, 100)
    assert prog.comprar("cachorro", "golden") == "ok"
    assert prog.moedas == 100 - SK.info("cachorro", "golden")[2]
    assert prog.possui("cachorro", "golden") and prog.skin_atual("cachorro") == "golden"


def test_nao_compra_sem_moedas(prog):
    ganhar(prog, 10)
    assert prog.comprar("cachorro", "golden") == "sem_moedas"
    assert prog.moedas == 10 and not prog.possui("cachorro", "golden")


def test_nao_paga_duas_vezes(prog):
    ganhar(prog, 500)
    prog.comprar("gato", "laranja")
    saldo = prog.moedas
    assert prog.comprar("gato", "laranja") == "ja_tem"
    assert prog.moedas == saldo
    assert prog.comprar("gato", "unicornio") == "inexistente"


def test_so_equipa_o_que_tem(prog):
    assert not prog.equipar("gato", "branco")
    ganhar(prog, 1000)
    prog.comprar("gato", "branco"); prog.equipar("gato", "cinza")
    assert prog.skin_atual("gato") == "cinza"
    assert prog.equipar("gato", "branco") and prog.skin_atual("gato") == "branco"


def test_skins_compradas_persistem(prog):
    ganhar(prog, 100)
    prog.comprar("cachorro", "golden")
    outro = estatisticas.Progresso()
    assert outro.possui("cachorro", "golden") and outro.skin_atual("cachorro") == "golden"


def test_catalogo_precos_crescentes_e_inicial_gratis():
    for a in SK.ANIMAIS:
        precos = [s[2] for s in SK.lista(a)]
        assert precos[0] == 0 and precos == sorted(precos) and len(set(precos)) == len(precos)


# ------------------------------------------------------------- conquistas
def test_conquista_por_metros_nao_repete(prog):
    _, novas = prog.registrar_partida(partida_com(120))
    assert "primeiros_passos" in [n[0] for n in novas]
    _, novas = prog.registrar_partida(partida_com(120))
    assert novas == []


def test_conquista_por_total_acumulado(prog):
    for _ in range(4):
        prog.registrar_partida(partida_com(10, comidas=30))
    assert prog.conquistada("guloso")                # 100 comidas no total


def test_conquista_por_comidas_em_uma_partida(prog):
    novas = prog.checar_conquistas(partida_com(20, comidas=10))
    assert "lanchinho" in [n[0] for n in novas]


def test_conquista_primeira_compra(prog):
    ganhar(prog, 100)
    prog.comprar("cachorro", "golden")
    assert "primeira_compra" in [n[0] for n in prog.checar_conquistas()]


def test_conquista_todas_as_skins(prog):
    ganhar(prog, 10_000)
    for s in SK.lista("gato")[1:]:
        prog.comprar("gato", s[0])
    ids = [n[0] for n in prog.checar_conquistas()]
    assert "amigo_dos_gatos" in ids and "amigo_dos_caes" not in ids


def test_conquista_jogar_com_os_dois(prog):
    prog.registrar_partida(partida_com(10), "gato")
    assert not prog.conquistada("dois_lados")
    prog.registrar_partida(partida_com(10), "cachorro")
    assert prog.conquistada("dois_lados")


def test_todas_as_conquistas_sao_possiveis_sem_depender_de_um_personagem_secreto():
    ids = [c[0] for c in estatisticas.CONQUISTAS]
    assert len(ids) == len(set(ids))


def test_apagar_progresso_mantem_so_o_som(prog):
    ganhar(prog, 500)
    prog.comprar("cachorro", "golden")
    prog.registrar_partida(partida_com(400, comidas=5), "gato")
    prog.dados["musica"] = False
    prog.apagar()
    assert prog.recorde == 0 and prog.moedas == 0 and prog.dados["conquistas"] == []
    assert not prog.possui("cachorro", "golden") and prog.dados["musica"] is False
    assert estatisticas.PADRAO["conquistas"] == []          # o padrão não foi contaminado
