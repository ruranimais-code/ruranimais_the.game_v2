"""Testes das regras do jogo (não abrem janela). Rode com:  python -m pytest -q"""
import pytest

import config as C
from cenario import sequencia_de_cenarios
from logica import Comida, Obstaculo, Partida, colide

DT = 1 / 60


def rodar(p, segundos):
    for _ in range(int(segundos / DT)):
        p.atualizar(DT)


def limpa(**kw):
    """Partida vazia (sem comidas nem obstáculos): a gente coloca só o que quer testar."""
    p = Partida(semente=1)
    p._proximo_x = 1e12
    p.comidas.clear()
    for k, v in kw.items():
        setattr(p, k, v)
    return p


def eventos(p):
    return [e[0] for e in p.eventos]


# ------------------------------------------------------------------ colisão
def test_colide_encostar_nao_conta():
    assert colide((0, 0, 10, 10), (5, 5, 10, 10))
    assert not colide((0, 0, 10, 10), (10, 0, 10, 10))


# ------------------------------------------------------------------- corrida
def test_corre_sozinho_e_conta_metros():
    p = limpa()
    rodar(p, 2.0)
    assert p.j.x == pytest.approx(C.VELOCIDADE_INICIAL * 2, rel=0.02)
    assert p.metros_inteiros == int(p.j.x / C.PX_POR_METRO)


def test_velocidade_aumenta_e_tem_limite():
    p = limpa()
    p.j.x = 1e6
    p.atualizar(DT)
    assert p.velocidade == C.VELOCIDADE_MAXIMA


# --------------------------------------------------------------------- pulo
def test_pulo_sai_do_chao_e_volta():
    p = limpa()
    p.pedir_pulo()
    rodar(p, 0.1)
    assert not p.j.no_chao and p.j.y < C.CHAO_Y
    rodar(p, 1.0)
    assert p.j.no_chao and p.j.y == C.CHAO_Y


def test_pulo_curto_quando_solta_a_tecla():
    alto, baixo = limpa(), limpa()
    alto.pedir_pulo(); baixo.pedir_pulo()
    for p in (alto, baixo):
        p.atualizar(DT)
    baixo.soltar_pulo()
    menor_y = {}
    for nome, p in (("alto", alto), ("baixo", baixo)):
        menor_y[nome] = min((p.atualizar(DT), p.j.y)[1] for _ in range(80))
    assert menor_y["baixo"] > menor_y["alto"] + 30     # y maior = mais baixo


# ------------------------------------------------------------------ caixote
def test_pousa_em_cima_do_caixote():
    p = limpa()
    cx = Obstaculo("caixote", 200)
    p.obstaculos.append(cx)
    p.pedir_pulo()
    for _ in range(120):
        p.atualizar(DT)
        if p.j.apoio is cx:
            break
    assert p.j.apoio is cx and p.j.y == cx.topo
    assert p.stats["erros"] == 0 and p.stats["caixotes"] == 1


def test_bater_de_frente_no_caixote_e_erro():
    p = limpa()
    p.obstaculos.append(Obstaculo("caixote", 200))
    rodar(p, 1.0)
    assert p.stats["erros"] == 1


# ----------------------------------------------------------------- espinhos
def test_espinhos_machucam_quem_corre_por_cima():
    p = limpa()
    p.obstaculos.append(Obstaculo("espinhos", 200))
    rodar(p, 1.0)
    assert p.stats["erros"] == 1


def test_pular_sobre_espinhos_nao_machuca():
    p = limpa()
    p.obstaculos.append(Obstaculo("espinhos", 100))
    p.pedir_pulo()
    rodar(p, 1.5)
    assert p.stats["erros"] == 0


# ----------------------------------------------------------------- barreira
def test_barreira_em_pe_machuca():
    p = limpa()
    p.obstaculos.append(Obstaculo("barreira", 200))
    rodar(p, 1.0)
    assert p.stats["erros"] == 1


def test_deslizar_passa_por_baixo_da_barreira():
    p = limpa()
    p.obstaculos.append(Obstaculo("barreira", 250))
    p.deslizar(True)
    rodar(p, 0.9)
    assert p.stats["erros"] == 0 and p.stats["deslizes"] == 1


def test_pular_sobre_a_barreira_funciona():
    p = limpa()
    p.obstaculos.append(Obstaculo("barreira", 110))
    p.pedir_pulo()
    rodar(p, 1.5)
    assert p.stats["erros"] == 0


def test_nao_levanta_embaixo_da_barreira():
    """Soltar o deslize debaixo da tábua não pode empurrar o bichinho para dentro dela."""
    p = limpa()
    p.obstaculos.append(Obstaculo("barreira", 250))
    p.deslizar(True)
    rodar(p, 0.8)                      # já está embaixo da tábua
    p.deslizar(False)                  # solta a tecla ali mesmo
    rodar(p, 0.8)
    assert p.stats["erros"] == 0


def test_janela_de_pulo_sobre_a_barreira_e_humana():
    """Pular por cima da barreira não pode exigir precisão de milissegundos."""
    acertos = 0
    passo = 5
    for d in range(30, 420, passo):             # distância até a barreira na hora de apertar pular
        p = limpa()
        p.obstaculos.append(Obstaculo("barreira", d))
        p.pedir_pulo()
        rodar(p, 1.6)
        acertos += p.stats["erros"] == 0
    janela_s = acertos * passo / C.VELOCIDADE_INICIAL
    assert janela_s >= 0.16, f"janela de apenas {janela_s:.2f} s"


# ------------------------------------------------------------------- comidas
def test_encostar_na_comida_pega_sem_apertar_nada():
    p = limpa(dist_fogo=200.0)
    p.comidas.append(Comida(150, C.CHAO_Y - 36, 2))
    rodar(p, 0.6)
    assert p.comidas_pegas == 1 and p.moedas == C.VALOR_COMIDA
    assert p.lista_comidas == [2]
    assert "comida" in eventos(p)
    assert p.dist_fogo > 200.0 - C.FOGO_AVANCO              # a comida empurra o fogo para trás


def test_comida_so_conta_uma_vez():
    p = limpa()
    p.comidas.append(Comida(150, C.CHAO_Y - 36, 0))
    rodar(p, 1.0)
    assert p.comidas_pegas == 1


def test_comida_alta_exige_pular():
    parado, pulando = limpa(), limpa()
    for p in (parado, pulando):
        p.comidas.append(Comida(250, C.CHAO_Y - 130, 0))
    pulando.pedir_pulo()
    rodar(parado, 1.2)
    rodar(pulando, 1.2)
    assert parado.comidas_pegas == 0 and pulando.comidas_pegas == 1


def test_comida_sob_a_barreira_e_de_quem_desliza():
    p = limpa()
    p.obstaculos.append(Obstaculo("barreira", 300))
    for i in range(3):
        p.comidas.append(Comida(330 + i * 36, C.CHAO_Y - 24, 0))
    p.deslizar(True)
    rodar(p, 1.1)
    assert p.stats["erros"] == 0 and p.comidas_pegas == 3


def test_comida_nao_e_pega_depois_de_passar_longe():
    p = limpa()
    p.comidas.append(Comida(250, C.CHAO_Y - 200, 0))         # muito alta: nem pulando
    p.pedir_pulo()
    rodar(p, 1.2)
    assert p.comidas_pegas == 0


def test_comida_recupera_fogo_ate_o_limite():
    p = limpa()
    p.dist_fogo = C.FOGO_DIST_MAXIMA
    p.comidas.append(Comida(40, C.CHAO_Y - 36, 0))
    p.atualizar(DT)
    assert p.dist_fogo <= C.FOGO_DIST_MAXIMA


# --------------------------------------------------------------------- fogo
def test_batida_aproxima_o_fogo_e_da_invulnerabilidade():
    p = limpa()
    d0 = p.dist_fogo
    p.obstaculos.append(Obstaculo("caixote", 200))
    p.obstaculos.append(Obstaculo("espinhos", 205))
    rodar(p, 0.6)
    assert p.dist_fogo < d0 - C.FOGO_PENALIDADE * 0.9
    assert p.stats["erros"] == 1            # o segundo obstáculo não bate (invulnerável)


def test_fogo_alcanca_e_termina_o_jogo():
    p = limpa(dist_fogo=C.FOGO_DISTANCIA_MORTE + 1)
    rodar(p, 1.0)
    assert p.fim and "fim" in eventos(p)
    x = p.j.x
    rodar(p, 0.5)
    assert p.j.x == x                         # nada mais se mexe depois do fim


# ------------------------------------------------------- geração infinita
def test_geracao_infinita_tem_obstaculos_e_comidas():
    p = Partida(semente=7)
    tipos, comidas = set(), 0
    for _ in range(60 * 600):
        p.j.x += 400 * DT                  # só anda, para ver o que é gerado
        p._gerar()
        tipos |= {o.tipo for o in p.obstaculos}
        comidas += len(p.comidas)
        p._limpar()
        if p.j.x > 100_000:
            break
    assert tipos == {"caixote", "espinhos", "barreira"}
    assert comidas > 100


def test_comidas_ficam_ao_alcance_do_jogador():
    """Nenhuma comida pode nascer alta demais para um pulo completo (nem enterrada no chão)."""
    p = Partida(semente=3)
    p.j.x = 60_000
    p._gerar()
    altura_max = C.VEL_PULO ** 2 / (2 * C.GRAVIDADE)
    for c in p.comidas:
        h = C.CHAO_Y - c.cy
        assert 10 <= h <= altura_max + 40 + C.CAIXOTE[1], h


def test_mesma_semente_gera_a_mesma_fase():
    def fase(seed):
        p = Partida(semente=seed)
        p.j.x = 20000
        p._gerar()
        return [(o.tipo, o.x) for o in p.obstaculos], [(c.cx, c.cy) for c in p.comidas]
    assert fase(3) == fase(3)


# ----------------------------------------------------------------- cenários
def test_ciclo_de_cenarios():
    g = sequencia_de_cenarios()
    seq = [next(g) for _ in range(80)]
    assert seq[:7] == ["inicial", "2", "3", "4", "5", "4", "5"]
    i = seq.index("3", 3)                          # o 3 que fecha o miolo
    assert seq[i + 1:i + 4] == ["inicial", "2", "3"]
    assert set(seq[3:i]) == {"4", "5"}
