"""Confere que toda skin do catálogo tem todos os quadros, e que as comidas existem."""
import glob
import json
import os

import pytest

import config as C
import skins as SK
from PIL import Image

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ANIM = os.path.join(RAIZ, "assets", "animais")
INFO = json.load(open(os.path.join(ANIM, "info.json"), encoding="utf-8"))
CASOS = [(a, s[0], an) for a in SK.ANIMAIS for s in SK.lista(a) for an in ("correr", "parado", "pulo", "deslize")]


@pytest.mark.parametrize("animal,skin,anim", CASOS)
def test_quadros_da_skin(animal, skin, anim):
    arqs = glob.glob(os.path.join(ANIM, animal, skin, f"{anim}_*.png"))
    assert len(arqs) == INFO[animal][anim]["quadros"] > 0
    for a in arqs:
        im = Image.open(a)
        assert im.size == (C.SPRITE_TAM, C.SPRITE_TAM) and im.mode == "RGBA"


@pytest.mark.parametrize("animal", SK.ANIMAIS)
def test_pes_no_chao_e_deslize_cabe_sob_a_barreira(animal):
    """O desenho tem os pés na base do quadro; o deslize é baixo o bastante para o vão de 51 px."""
    skin = SK.inicial(animal)
    for anim in ("correr", "deslize"):
        for a in glob.glob(os.path.join(ANIM, animal, skin, f"{anim}_*.png")):
            bb = Image.open(a).getbbox()
            assert C.SPRITE_TAM - bb[3] <= 8, f"{a} flutua {C.SPRITE_TAM - bb[3]} px"
            if anim == "deslize":
                assert bb[3] - bb[1] <= 51, f"{a} alto demais para deslizar"


def test_comidas_existem():
    for i in range(C.COMIDA_VARIANTES):
        assert os.path.exists(os.path.join(RAIZ, "assets", "objetos", f"comida_{i}.png"))
