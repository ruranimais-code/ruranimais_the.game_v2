"""Teste de ponta a ponta: menu -> escolha -> corrida -> pausa -> fim -> loja (usa o PyGame falso)."""
import pytest

import conftest

pytestmark = pytest.mark.skipif(not conftest.USANDO_FALSO,
                                reason="usa o teclado simulado do PyGame falso")

import pygame as pg                     # noqa: E402

import config as C                      # noqa: E402
import estatisticas                     # noqa: E402
import main                             # noqa: E402
import skins as SK                      # noqa: E402

DT = 1 / 60


@pytest.fixture
def jogo(tmp_path, monkeypatch):
    monkeypatch.setattr(estatisticas, "ARQUIVO", str(tmp_path / "save.json"))
    pg.estado.pressionadas.clear()
    tela = pg.display.set_mode((C.LARGURA, C.ALTURA))
    return main.Jogo(tela)


def tecla(j, k):
    pg.estado.pressionadas.add(k)
    j.evento(pg.Event(pg.KEYDOWN, key=k))
    pg.estado.pressionadas.discard(k)
    j.evento(pg.Event(pg.KEYUP, key=k))


def rodar(j, s):
    for _ in range(int(s / DT)):
        j.atualizar(DT)


def comecar(j, animal="cachorro"):
    tecla(j, pg.K_RETURN)                                   # Iniciar jogo
    assert j.estado == "escolha"
    while SK.ANIMAIS[j.sel] != animal:
        tecla(j, pg.K_RIGHT)
    tecla(j, pg.K_RETURN)
    assert j.estado == "jogando"


def morrer(j):
    while j.estado == "jogando":
        rodar(j, 0.5)
    rodar(j, main.TEMPO_MORTE + 0.2)
    assert j.estado == "fim"


def test_fluxo_completo(jogo):
    j = jogo
    assert j.estado == "menu"
    j.desenhar()
    comecar(j)
    rodar(j, 1.0)
    j.desenhar()
    tecla(j, pg.K_p)
    assert j.estado == "pausa"
    x = j.partida.j.x
    rodar(j, 1.0)
    assert j.partida.j.x == x                  # pausa congela
    tecla(j, pg.K_ESCAPE)
    assert j.estado == "jogando"
    morrer(j)                                  # sem apertar nada, o fogo acaba pegando
    j.desenhar()
    tecla(j, pg.K_m)                           # bloqueado nos primeiros 0,8 s
    assert j.estado == "fim"
    rodar(j, 1.0)
    tecla(j, pg.K_m)
    assert j.estado == "menu"
    assert j.prog.dados["partidas"] == 1


def test_escolha_do_bichinho_vale_na_corrida_e_e_lembrada(jogo):
    comecar(jogo, "gato")
    assert jogo.mundo.animal == "gato" and jogo.prog.dados["animal"] == "gato"
    jogo.voltar_ao_menu()
    tecla(jogo, pg.K_RETURN)
    assert jogo.sel == SK.ANIMAIS.index("gato")        # a escolha abre no último bichinho usado


def test_esc_na_escolha_volta_ao_menu(jogo):
    tecla(jogo, pg.K_RETURN)
    tecla(jogo, pg.K_ESCAPE)
    assert jogo.estado == "menu"


def test_fim_ignora_teclas_nos_primeiros_instantes(jogo):
    comecar(jogo)
    while jogo.estado == "jogando":
        rodar(jogo, 0.5)
    rodar(jogo, main.TEMPO_MORTE + 0.2)
    assert jogo.estado == "fim"
    tecla(jogo, pg.K_r)
    assert jogo.estado == "fim"                # ainda bloqueado
    rodar(jogo, 1.0)
    tecla(jogo, pg.K_r)
    assert jogo.estado == "jogando"            # jogou de novo


def test_comidas_da_corrida_viram_saldo_da_loja(jogo):
    comecar(jogo)
    jogo.partida.comidas_pegas = 25
    jogo.partida.stats["comidas"] = 25
    morrer(jogo)
    assert jogo.resultado["comidas"] >= 25
    assert jogo.prog.moedas == jogo.resultado["comidas"] == jogo.prog.dados["total_comidas"]


def test_loja_comprar_equipar_e_voltar_para_a_tela_de_fim(jogo):
    jogo.prog.dados["moedas"] = 100
    comecar(jogo, "cachorro")
    morrer(jogo)
    rodar(jogo, 1.0)
    tecla(jogo, pg.K_l)                                # atalho para a loja
    assert jogo.estado == "loja"
    assert SK.ANIMAIS[jogo.loja_aba] == "cachorro" and jogo.sel == 0
    tecla(jogo, pg.K_RIGHT)                            # golden (60)
    tecla(jogo, pg.K_RETURN)
    assert jogo.prog.possui("cachorro", "golden") and jogo.prog.skin_atual("cachorro") == "golden"
    assert jogo.prog.moedas == 100 + jogo.resultado["comidas"] - 60
    tecla(jogo, pg.K_RIGHT)                            # pastor (120): não dá
    tecla(jogo, pg.K_RETURN)
    assert not jogo.prog.possui("cachorro", "pastor") and "Faltam" in jogo.msg_loja[0]
    tecla(jogo, pg.K_TAB)                              # aba do gato
    assert SK.ANIMAIS[jogo.loja_aba] == "gato"
    jogo.desenhar()
    tecla(jogo, pg.K_ESCAPE)
    assert jogo.estado == "fim"
    tecla(jogo, pg.K_r)                                # já pode jogar de novo, sem esperar
    assert jogo.estado == "jogando" and jogo.mundo.skin == "golden"


def test_skin_equipada_aparece_na_corrida(jogo):
    jogo.prog.dados["moedas"] = 500
    jogo.prog.comprar("gato", "preto")
    comecar(jogo, "gato")
    assert (jogo.mundo.animal, jogo.mundo.skin) == ("gato", "preto")


def test_menu_loja_conquistas_e_configuracoes(jogo):
    tecla(jogo, pg.K_DOWN); tecla(jogo, pg.K_RETURN)
    assert jogo.estado == "loja"
    jogo.desenhar()
    tecla(jogo, pg.K_ESCAPE)
    assert jogo.estado == "menu" and jogo.sel == 1
    tecla(jogo, pg.K_DOWN); tecla(jogo, pg.K_RETURN)
    assert jogo.estado == "conquistas"
    jogo.desenhar()
    tecla(jogo, pg.K_ESCAPE)
    assert jogo.estado == "menu" and jogo.sel == 2
    tecla(jogo, pg.K_DOWN); tecla(jogo, pg.K_RETURN)
    assert jogo.estado == "config"
    tecla(jogo, pg.K_RETURN)                   # liga/desliga a música
    assert jogo.prog.dados["musica"] is False
    jogo.desenhar()
    tecla(jogo, pg.K_ESCAPE)
    assert jogo.estado == "menu"


def test_apagar_progresso_pede_confirmacao(jogo):
    jogo.prog.dados["recorde_metros"] = 999
    jogo.prog.dados["moedas"] = 77
    jogo.ir_para("config", 3)
    tecla(jogo, pg.K_RETURN)
    assert jogo.prog.recorde == 999            # 1º Enter só pede confirmação
    tecla(jogo, pg.K_RETURN)
    assert jogo.prog.recorde == 0 and jogo.prog.moedas == 0


def test_sons_certos_nas_acoes(jogo):
    tocados = []
    jogo.som = tocados.append
    comecar(jogo)
    tecla(jogo, pg.K_SPACE)
    rodar(jogo, 3.0)                           # as primeiras comidas ficam no caminho
    assert "pulo" in tocados and "comida" in tocados


def test_mouse_no_menu_e_na_loja(jogo):
    r = jogo.telas.rets_menu[1]
    jogo.evento(pg.Event(pg.MOUSEMOTION, pos=r.center))
    assert jogo.sel == 1
    jogo.evento(pg.Event(pg.MOUSEBUTTONDOWN, pos=r.center, button=1))
    assert jogo.estado == "loja"
    aba_gato = jogo.telas.rets_abas[1]
    jogo.evento(pg.Event(pg.MOUSEBUTTONDOWN, pos=aba_gato.center, button=1))
    assert SK.ANIMAIS[jogo.loja_aba] == "gato"


def test_todas_as_telas_desenham_sem_erro_com_todas_as_skins(jogo):
    jogo.prog.dados["moedas"] = 10_000
    for a in SK.ANIMAIS:
        for s in SK.lista(a):
            jogo.prog.comprar(a, s[0])
    for animal in SK.ANIMAIS:
        for s in SK.lista(animal):
            jogo.prog.equipar(animal, s[0])
            jogo.voltar_ao_menu()
            comecar(jogo, animal)
            rodar(jogo, 0.5)
            jogo.desenhar()
    for estado in ("menu", "escolha", "loja", "conquistas", "config"):
        jogo.ir_para(estado)
        jogo.desenhar()
