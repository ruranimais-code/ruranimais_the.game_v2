"""
Progresso do jogador (salvo em save.json): recorde, totais, saldo de comidas para a
loja, skins compradas/equipadas e conquistas.

O jogo registra números de cada corrida (metros, comidas, pulos...). As conquistas só
*consultam* esses números, então para criar uma conquista nova basta acrescentar uma
linha na lista CONQUISTAS, sem mexer no resto do jogo.
"""
import copy
import json
import os

import skins as SK

PASTA = os.path.dirname(os.path.abspath(__file__))
ARQUIVO = os.path.join(PASTA, "save.json")

PADRAO = {
    "recorde_metros": 0,
    "recorde_comidas": 0,
    "total_metros": 0,
    "total_comidas": 0,
    "total_pulos": 0,
    "total_deslizes": 0,
    "total_caixotes": 0,
    "total_erros": 0,
    "partidas": 0,
    "partidas_por_animal": {"cachorro": 0, "gato": 0},
    "conquistas": [],
    "moedas": 0,                                   # saldo para gastar na loja (1 comida = 1 moeda)
    "animal": "cachorro",                          # último bichinho escolhido
    "skins": [SK.chave(a, SK.inicial(a)) for a in SK.ANIMAIS],      # compradas ("cachorro/golden")
    "skin_ativa": {a: SK.inicial(a) for a in SK.ANIMAIS},           # equipada em cada animal
    "musica": True,
    "efeitos": True,
}

# (id, título, descrição, função(corrida, totais) -> bool)
# "corrida" = números da partida em andamento: metros, comidas, metros_sem_erro, pior_fogo
# "totais"  = números de todas as partidas (incluindo a atual) e da loja
CONQUISTAS = [
    ("primeiros_passos", "Primeiros passos", "Corra 100 m em uma partida",
     lambda c, t: c["metros"] >= 100),
    ("fogo_nos_calcanhares", "Fogo nos calcanhares", "Corra 500 m em uma partida",
     lambda c, t: c["metros"] >= 500),
    ("maratonista", "Maratonista", "Corra 1000 m em uma partida",
     lambda c, t: c["metros"] >= 1000),
    ("lenda", "Lenda do campus", "Corra 2500 m em uma partida",
     lambda c, t: c["metros"] >= 2500),
    ("primeira_mordida", "Primeira mordida", "Pegue sua primeira comida",
     lambda c, t: t["total_comidas"] >= 1),
    ("lanchinho", "Lanchinho", "Pegue 10 comidas em uma partida",
     lambda c, t: c["comidas"] >= 10),
    ("banquete", "Banquete", "Pegue 30 comidas em uma partida",
     lambda c, t: c["comidas"] >= 30),
    ("guloso", "Guloso", "Pegue 100 comidas no total",
     lambda c, t: t["total_comidas"] >= 100),
    ("comilao", "Comilão", "Pegue 500 comidas no total",
     lambda c, t: t["total_comidas"] >= 500),
    ("primeira_compra", "Visual novo", "Compre sua primeira skin",
     lambda c, t: t["skins_compradas"] >= 1),
    ("amigo_dos_caes", "Amigo dos cães", "Desbloqueie todas as skins de cachorro",
     lambda c, t: t["skins_cachorro"] >= len(SK.lista("cachorro"))),
    ("amigo_dos_gatos", "Amigo dos gatos", "Desbloqueie todas as skins de gato",
     lambda c, t: t["skins_gato"] >= len(SK.lista("gato"))),
    ("dois_lados", "Cão e gato", "Jogue uma partida com o gato e outra com o cachorro",
     lambda c, t: t["jogou_gato"] and t["jogou_cachorro"]),
    ("pula_pula", "Pula-pula", "Pule 100 vezes no total",
     lambda c, t: t["total_pulos"] >= 100),
    ("limpinho", "Sem arranhão", "Corra 300 m sem bater em nada",
     lambda c, t: c["metros_sem_erro"] >= 300),
    ("quase_torrado", "Quase torrado", "Chegue a 100 m com o fogo a menos de 50 px de você",
     lambda c, t: c["pior_fogo"] < 50 and c["metros"] >= 100),
]

_CORRIDA_ZERADA = dict(metros=0, comidas=0, metros_sem_erro=0, pior_fogo=999, fim=False)


class Progresso:
    def __init__(self):
        self.dados = copy.deepcopy(PADRAO)      # cópia profunda: listas/dicts não podem ser compartilhados
        self.carregar()

    # ------------------------------------------------------------ arquivo
    def carregar(self):
        try:
            with open(ARQUIVO, "r", encoding="utf-8") as f:
                lido = json.load(f)
        except (OSError, ValueError):
            return
        if not isinstance(lido, dict):
            return
        for k, padrao in PADRAO.items():
            if k not in lido:
                continue
            v = lido[k]
            if isinstance(padrao, dict) and isinstance(v, dict):
                self.dados[k].update(v)          # mescla (ex.: skin_ativa de cada animal)
            elif isinstance(v, type(padrao)):
                self.dados[k] = v
        self._corrigir()

    def _corrigir(self):
        """Garante que o save é coerente (skin equipada existe e está comprada, etc.)."""
        d = self.dados
        for a in SK.ANIMAIS:
            ini = SK.chave(a, SK.inicial(a))
            if ini not in d["skins"]:
                d["skins"].append(ini)
            atual = d["skin_ativa"].get(a)
            if not SK.info(a, atual) or SK.chave(a, atual) not in d["skins"]:
                d["skin_ativa"][a] = SK.inicial(a)
        d["skins"] = [k for k in d["skins"] if k in SK.todas_as_chaves()]
        if d["animal"] not in SK.ANIMAIS:
            d["animal"] = SK.ANIMAIS[0]
        d["moedas"] = max(0, d["moedas"])

    def salvar(self):
        try:
            with open(ARQUIVO, "w", encoding="utf-8") as f:
                json.dump(self.dados, f, ensure_ascii=False, indent=2)
        except OSError:
            pass  # sem permissão de escrita: o jogo segue sem salvar

    def apagar(self):
        """Zera recorde, totais, skins e conquistas (mantém só as opções de som)."""
        musica, efeitos = self.dados["musica"], self.dados["efeitos"]
        self.dados = copy.deepcopy(PADRAO)
        self.dados["musica"], self.dados["efeitos"] = musica, efeitos
        self.salvar()

    # ------------------------------------------------------------ consultas
    @property
    def recorde(self):
        return self.dados["recorde_metros"]

    @property
    def moedas(self):
        return self.dados["moedas"]

    def conquistada(self, id_):
        return id_ in self.dados["conquistas"]

    def possui(self, animal, skin):
        return SK.chave(animal, skin) in self.dados["skins"]

    def skin_atual(self, animal):
        return self.dados["skin_ativa"][animal]

    def qtd_skins(self, animal):
        return sum(1 for s in SK.lista(animal) if self.possui(animal, s[0]))

    # ------------------------------------------------------------------ loja
    def comprar(self, animal, skin):
        """Tenta comprar. Devolve 'ok', 'ja_tem', 'sem_moedas' ou 'inexistente'."""
        item = SK.info(animal, skin)
        if item is None:
            return "inexistente"
        if self.possui(animal, skin):
            return "ja_tem"
        if self.dados["moedas"] < item[2]:
            return "sem_moedas"
        self.dados["moedas"] -= item[2]
        self.dados["skins"].append(SK.chave(animal, skin))
        self.dados["skin_ativa"][animal] = skin          # já equipa a skin recém-comprada
        self.salvar()
        return "ok"

    def equipar(self, animal, skin):
        if not self.possui(animal, skin):
            return False
        self.dados["skin_ativa"][animal] = skin
        self.salvar()
        return True

    def escolher_animal(self, animal):
        if animal in SK.ANIMAIS:
            self.dados["animal"] = animal

    # ------------------------------------------------------ conquistas
    def _totais(self, partida=None, animal=None):
        d = self.dados
        s = partida.stats if partida else {}
        compradas = sum(1 for k in d["skins"] if k not in
                        [SK.chave(a, SK.inicial(a)) for a in SK.ANIMAIS])
        por = d["partidas_por_animal"]
        return {
            "total_comidas": d["total_comidas"] + s.get("comidas", 0),
            "total_pulos": d["total_pulos"] + s.get("pulos", 0),
            "total_deslizes": d["total_deslizes"] + s.get("deslizes", 0),
            "total_caixotes": d["total_caixotes"] + s.get("caixotes", 0),
            "total_metros": d["total_metros"],
            "partidas": d["partidas"],
            "skins_compradas": compradas,
            "skins_cachorro": self.qtd_skins("cachorro"),
            "skins_gato": self.qtd_skins("gato"),
            "jogou_cachorro": por.get("cachorro", 0) > 0 or (partida is not None and animal == "cachorro"),
            "jogou_gato": por.get("gato", 0) > 0 or (partida is not None and animal == "gato"),
        }

    @staticmethod
    def _numeros_corrida(partida):
        return {
            "metros": partida.metros_inteiros,
            "comidas": partida.stats["comidas"],
            "metros_sem_erro": (partida.j.x - partida.metros_sem_erro_desde) / 64.0,
            "pior_fogo": partida.stats["pior_fogo"],
            "fim": partida.fim,
        }

    def _avaliar(self, corrida, totais):
        novas = []
        for id_, titulo, desc, regra in CONQUISTAS:
            if id_ not in self.dados["conquistas"] and regra(corrida, totais):
                self.dados["conquistas"].append(id_)
                novas.append((id_, titulo, desc))
        return novas

    def checar_conquistas(self, partida=None, animal=None):
        """Confere as conquistas (durante a corrida, ou após uma compra se partida=None).
        Devolve a lista das recém-desbloqueadas: (id, título, descrição)."""
        corrida = self._numeros_corrida(partida) if partida else dict(_CORRIDA_ZERADA)
        novas = self._avaliar(corrida, self._totais(partida, animal))
        if novas:
            self.salvar()
        return novas

    # ------------------------------------------------------------ fim de partida
    def registrar_partida(self, partida, animal="cachorro"):
        """Soma a partida aos totais, guarda as comidas como moedas e atualiza recordes.
        Devolve (bateu_recorde, conquistas_novas)."""
        d, s = self.dados, partida.stats
        metros = partida.metros_inteiros
        novo_recorde = metros > d["recorde_metros"]
        d["recorde_metros"] = max(d["recorde_metros"], metros)
        d["recorde_comidas"] = max(d["recorde_comidas"], s["comidas"])
        d["total_metros"] += metros
        d["total_comidas"] += s["comidas"]
        d["total_pulos"] += s["pulos"]
        d["total_deslizes"] += s["deslizes"]
        d["total_caixotes"] += s["caixotes"]
        d["total_erros"] += s["erros"]
        d["partidas"] += 1
        d["moedas"] += partida.moedas
        if animal in d["partidas_por_animal"]:
            d["partidas_por_animal"][animal] += 1
        # confere as conquistas com os totais já atualizados
        novas = self._avaliar(self._numeros_corrida(partida), self._totais())
        self.salvar()
        return novo_recorde, novas
